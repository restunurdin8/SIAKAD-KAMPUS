-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 07 Mar 2016 pada 18.33
-- Versi Server: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u6189264_sisfo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `id_level` int(1) NOT NULL DEFAULT '1',
  `username` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `keterangan` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `telepon` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `foto` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'no_foto.jpg',
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`ID`, `id_level`, `username`, `password`, `keterangan`, `nama_lengkap`, `email`, `telepon`, `foto`, `aktif`) VALUES
(4, 1, 'admin', '51299bd3dbe0951deab2a1c1aeb35e7fe0008cddbfcb39e00b7a385dffaa463b217a24e369c2a41fcaf95a159f5f20d2cbd8584792dd294af64cdcc9b339f5f1', 'Programer', 'Superadmin', 'sofiyanyanyan90@gmail.com', '085696371900', 'akademik.jpg', 'Y'),
(5, 1, 'prodipai', 'e959ff21b941dd9ca11a4db2add4fa61cb7c2df7a8f03b7c4ca2466b05b5f4899574ef5b1e880812da3ace98d0beacb1419c6c7ebda7169aabc3b1fb0f92f04e', 'Ketua Prodi PAI', 'Drs.Lili Sadeli, M.Pd.I', '', '', '', 'Y'),
(6, 1, 'prodieksya', '1c491c214a0b0778a0fee8f8e0e4651d97ffa06cc1dfcf0563844876867a879ee9f76b67051caa8ed73873ddfac66b2c1ecea69357e584af4a9d216de50a43af', 'Ketua Prodi Ekonomi Syariah', 'H. Agus Hermawan, M.Ag.', '', '', '', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `agama`
--

CREATE TABLE `agama` (
  `ID` int(11) NOT NULL,
  `nama` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `agama`
--

INSERT INTO `agama` (`ID`, `nama`, `aktif`) VALUES
(1, 'ISLAM', 'Y'),
(2, 'KRISTEN KATOLIK', 'Y'),
(3, 'KRISTEN PROTESTAN', 'Y'),
(4, 'BUDHA', 'Y'),
(5, 'HINDU', 'Y'),
(6, 'LAIN-LAIN', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `akademik`
--

CREATE TABLE `akademik` (
  `ID` int(11) NOT NULL,
  `id_level` int(2) NOT NULL DEFAULT '3',
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `username` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `keterangan` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `telepon` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `alamat` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `foto` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'no_foto.jpg',
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `akademik`
--

INSERT INTO `akademik` (`ID`, `id_level`, `Identitas_ID`, `Jurusan_ID`, `username`, `password`, `nama_lengkap`, `keterangan`, `email`, `telepon`, `alamat`, `foto`, `aktif`) VALUES
(7, 3, 213131, 86208, 'prodipai', 'e959ff21b941dd9ca11a4db2add4fa61cb7c2df7a8f03b7c4ca2466b05b5f4899574ef5b1e880812da3ace98d0beacb1419c6c7ebda7169aabc3b1fb0f92f04e', 'Drs. Lili Sadeli, M.Pd.I', 'Ketua Prodi Agama Islam', '', '', '', 'no_foto.jpg', 'Y'),
(6, 3, 213131, 60202, 'prodieksyar', '1c491c214a0b0778a0fee8f8e0e4651d97ffa06cc1dfcf0563844876867a879ee9f76b67051caa8ed73873ddfac66b2c1ecea69357e584af4a9d216de50a43af', 'H. Agus Hermawan, M.Ag.', 'Ketua Prodi Ekonomi Syariah', '', '', '', 'no_foto.jpg', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `beritaawal`
--

CREATE TABLE `beritaawal` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `isi` text COLLATE latin1_general_ci NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `beritaawal`
--

INSERT INTO `beritaawal` (`id`, `tanggal`, `isi`, `gambar`, `aktif`) VALUES
(1, '2015-07-16', 'Pembuatan Aplikasi Sistem Informasi Akademik Kampus ini bertujuan sebagai bahan pembelajaran bagi para programmer di indonesia baik tingkat pemula, menegah,maupun mahir, sehingga dengan hadirnya pembelajaran ini kedepannya para programmer dapat membuat berbagai aplikasi lainnya dengan memahami konsep sederhana yang penulis sajikan ini \r\n\r\ndan didalam praktek pembuatan aplikasi tersebut jika para programmer sulit memahami jalannya program untuk segera merujuk kepada buku yang telah diterbitkan\r\n\r\n', 'icon.png', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `dosen`
--

CREATE TABLE `dosen` (
  `ID` int(10) NOT NULL,
  `id_level` int(1) NOT NULL DEFAULT '2',
  `username` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `password` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `NIDN` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `InstitusiInduk` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Homebase` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TempatLahir` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalLahir` date DEFAULT NULL,
  `KTP` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Agama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Alamat` text COLLATE latin1_general_ci,
  `Email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Handphone` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Keterangan` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Kota` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Propinsi` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Negara` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Gelar` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Jenjang_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Keilmuan` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Kelamin_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Jabatan_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JabatanDikti_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `TglBekerja` date NOT NULL,
  `StatusDosen_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `StatusKerja_ID` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL,
  `foto` varchar(100) COLLATE latin1_general_ci DEFAULT 'no foto.jpg'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `dosen`
--

INSERT INTO `dosen` (`ID`, `id_level`, `username`, `password`, `NIDN`, `nama_lengkap`, `Identitas_ID`, `Jurusan_ID`, `InstitusiInduk`, `Homebase`, `TempatLahir`, `TanggalLahir`, `KTP`, `Agama`, `Alamat`, `Email`, `Telepon`, `Handphone`, `Keterangan`, `Kota`, `Propinsi`, `Negara`, `Gelar`, `Jenjang_ID`, `Keilmuan`, `Kelamin_ID`, `Jabatan_ID`, `JabatanDikti_ID`, `TglBekerja`, `StatusDosen_ID`, `StatusKerja_ID`, `Aktif`, `foto`) VALUES
(1, 2, 'STAI044', 'f72ab66c9ac8be5d6415d3d13faf76692883f533a98714924d5fa8e4283a70bde889b4d817a7938ce02c8703c3c8bd35e5523c33548c69f3e32ae33133683af8', '', 'Yanyan Sofiyan', 213131, '60202,86208', '', '', 'Sumedang', '1989-07-16', '', 'ISLAM', 'Jl.Padjajaran No.01 Rt 05 Rw 02 Ds.Legok Kidul Kec.Paseh Kab.Sumedang Kode Pos 45381', 'sofiyanyanyan90@gmail.com', '', '085696371900', NULL, 'Sumedang', 'Jawa Barat', 'Indonesia', ',S.Kom', 'B', '', '', 'B', '0', '0000-00-00', '0', 'D', 'Y', 'akademik.jpg'),
(2, 2, 'STAI017', '1ce668382b9ffece55aecf6289a797c57abc8ce3d6bc8e11e5e9b931e156a141e8bce3416b708a90ef0b1c01b540178a5bc65507d484df5584da887fa458c679', '', 'Drs.A.Djuwaeni Soheh', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', '', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(3, 2, 'STAI018', '67fc7399b60fc876b2c9bc31be897c992d06bb303ce570899637864eed8d644b6f72741c48ee65e6f5b8bc46c918ac23f3a5c73dc74030f5657ee9284ec523cd', '', 'Drs.KH.Adam Malik Ibramin', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', '', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(4, 2, 'STAI019', '99d7afad5a5b3d9d97b7a0b6c0519e9bc57b121e7cff07c6a70c8543d0a879c23354b2b577bc7dc9365f942fc797fef3ea803ab30c1c364e1ba61c31f0e13483', '', 'Drs.Amin Irfan', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', '', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(5, 2, 'STAI020', '3f2e6a17b78e6210bc32130b0daa04180c82ec9efbaa0494705348fcbda4ec256766357b21d6aaf8c0e6052530ab785dc86163ea9e0e8ef7a066e12323ab5b3e', '', 'Dhita Tien S', 213131, '60202,86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(6, 2, 'STAI021', '86014e0bb52706d25062698ed06f9e3665788f41494a026b865ce7c6f1ea0d59b6b670e1e8853a26a9a4dc15465bca50d2e1e61d4b3d03fcac0d612dcc5aed9c', '', 'Drs.Dindin Saefudin', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(10, 2, 'STAI040', '79319a6bf444251a97efc3b102ac3435cf5ad085a64046aeb082334c9cf4c4f9a785a7422ddf4fdd98a9ede7212976fc5d542964d6f2e3be8e2a593ecf432056', '', 'Suherman', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Ag.,M.S.I', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(7, 2, 'STAI043', 'a21293c577333189e1c58c37c33ef430f74672c22081cb116914c50a10b39605f6a3b9738345e960cd2d0e0193975472b07e1b57fabf1cc9a0a1bb78e9d08e17', '', 'Drs.Taruna Sonjaya', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', '', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(8, 2, 'STAI042', '7a2432c8b865794b910f11295af22e246b688c93d7f4bc979ac0aa46f2b652f943a8372f921ca795bd6fbdeb3a5f47a3d37f1f55710acb7c64eea8f4dfbdbe09', '', 'Dra.Sutarti', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(9, 2, 'STAI041', 'e2df829d72764cddcb189b811371f491d053ae8e08e188dd73e3c3710123dc07c6a5d0f63dc1d7664f2611996dee98c0f9bbbcf3f2987cf8f4bfd302b6c60d48', '', 'Suhyat', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(11, 2, 'STAI039', 'ac6213783f6d944b154f9e0f6dd29fb05c0a4b34eef86eb4ef5b0766763215ebfa91bed037776141156c6f391486179196116d676f29c4ba4da168ccea934957', '', 'Riska Hermina Rahmawati', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(12, 2, 'STAI038', '9259e00727a287bc59e59114c800906ccca7fcf5b4cddd277aff29127f2cc6e5e70637941c008fc4d14c85d4ca8e80b076e13a1bcbde8aab33092d58976a2df0', '', 'Muslim Mubarok', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd.I', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(13, 2, 'STAI037', '1cfbb56d8205c557eba3f83d4858192cbb240a0762a359fad6899d9a7cae789dcffbc93ede454a34efd4bf2bb1e073c4c7b8df924b5dd871041c05fe025351c3', '', 'Drs.Munir Natsir', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Si', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(14, 2, 'STAI036', 'e87ce1d7c22195a6b2cb7f625c6a91c2e4d7e1b1faa2f34e551220aa62738d4e68c774f51caef6bbfd21a02074a30a91e8890f64c5cfbf0291e14d6a582d0e6e', '', 'Imron Mustofa', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Ag', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(15, 2, 'STAI035', 'e8f59750655ac32cb60cb47e33943500da0fc6b41bd8e41ee39ee1fbe2eae157855c41240075238870122b81ac383365d9cda287508499815f98c0e8b3301f9d', '', 'Hj.Winy Roswinawati', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Ag.,M.Si', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(16, 2, 'STAI034', 'd456ffa38a51a72f227f1990047ebe93d9943f177aae0c3fe18181a09e05c68b7aabdb3e7a663423d58a82c97abe47b630888618a86de1f78978d3077929811d', '', 'Hj Iin Inayah T', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',Dra.,M.M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(17, 2, 'STAI033', '9a7eb86a59c8408c60deca3d8450be2386f300ebff27197a5ede4518f1f0828a29cef3cafe92c595710d05af981829eed21b9d984b655ceedfcd362d72c93d78', '', 'Drs.H.Firdaus', 213131, '60202,86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(18, 2, 'STAI032', '8f009d7b7657ed6bb622a900b8e502bbdf846cb7ab7d2442ede5135d38536f6f1aeb42225ec112a0b6f1a074e3d1eef4ac485dd213ca948ff1bb8be49879fe9a', '', 'H.Dadang Alawi', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Ag.,M.Ag', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(19, 2, 'STAI031', '5e643254e32339d05c445a1dfe50531e2c81aa173f5ce123ba8a67e6904b04af89fb35a7ae889f988fafdb737dcdabfe0d41ae16467ecd3e35fa0123ed175333', '', 'H.Aep Sobandi', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',Drs', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(20, 2, 'STAI030', 'c65731aca7f26939985c43aafc9071670da558c72badf45006800b54cee77551698ab9ac6b6bb535985f193e040a31c2f84431359debf82421ed530e24cfef60', '', 'H.Rahmat', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Ag.,M.S.i', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(21, 2, 'STAI029', 'a49bbc9e8a4cebd66aebc4fdba48183088dd9452c371ca78dd75c7c0b6ac1398ac26cf82c7b27700bfe7502125e144ce6a4a1879755a70218f84ccaf02d5fc4d', '', 'H.Asep Sardi Somantri', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',Drs.,M.M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(22, 2, 'STAI028', 'd8755def69f26dcf00bbe2ece574c7e1efc7a687994b906d117685baaa7703b17b6fca13fa56f29ec76ac21c8ecd435bd1a6765b8bf3704773ad1bc63151d40a', '', 'H.Ading Sudiana', 213131, '60202,86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',Drs.,M.Si', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(23, 2, 'STAI027', '522655e62abd6c99b4bcfb7653a4c3b90e8458994f980093df3e4b40699521f31f442cfedd56073c0b652e6f8aaa5052104798b4826ff4d01682016f42414478', '', 'Ela Hodijah', 213131, '60202,86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Ag.,M.Pd.I', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(24, 2, 'STAI026', '1b9ad661576fdb7078494b1a9d8aeddcb7663811dddab7144bde9ceb7c3d6c302e7d9da22fc3c9ac36ab3f9e6cb89755ad5607da7fd744dfe3c7f234c3b916e4', '', 'Edi Junaedi', 213131, '60202,86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Hut.,S.Ag,M.Pd.I', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(25, 2, 'STAI025', '211dd0650c58e757e8e275d8b5f92a446a7bcab135801f777174280f05536ac72ddf44209ad77ea7c72b0e4ee8f61f39eb387018bf0a9dafe387bf9bd72ddd9f', '', 'Eddy Riady Husein', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',Drs', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(26, 2, 'STAI024', '5393a419ee1647831875e7c426e3d6b47a1aaaceb9527f577a52ce6ed5884b63073761c43f3762677ce79c8d78a38c4ed6b63e0f0240187a30dc4b98e9801799', '', 'Drs.Lili Sadeli', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd.I', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(27, 2, 'STAI023', '5b13fb11e3d29fe3ed060573cf3707d8f7cb41f67a18813370ffd468fcc509a7f3c7e8cab262e4e11cdfc257df092de04036d9f588ac8fcb8c71a2c5374ee120', '', 'Dr.H Rahman Setia', 213131, '60202,86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.M', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(28, 2, 'STAI022', 'b412d9fe64aa465bb82d7f31cb56af161a9ed17ee5e5f679da17cbf2541b99f7ccedfe0fc25d64708bf02623dc05fbb3e4fb044de937aba428d1ab3bc3f86a36', '', 'Dr.Dian Sukmara', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(29, 2, 'STAI001', '5dab0281bfecc19ff4031af086e77910e453583bca4acdefa3406fd8074a6d99147d1474b4f05217f5c4ce1c5e06f8e25583911e8df5b7aa41badd863eb5badf', '', 'Drs.A.Suherman', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(30, 2, 'STAI002', '4620be728f20a23c5ea151c683967ef29d6fe2fd3715607a4eb1becbc5613cb8888dbab0e86e9d96cd556dbf98701234bf079c7f8e9010cd9f6c7fa38c31b883', '', 'AA Kartiwa', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.M', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(31, 2, 'STAI003', 'e4757a936e37fc4faf74832f2c33778f013f9e0670d54a66c6f9d71bc7557f2a9f87954f04a217ed6dddb2a1a1a8432930d8f911c566f6e9377900dae21c5e0e', '', 'Abdul Hamid', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.M', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(32, 2, 'STAI004', '1e0071c479d9f476c10f221d5287e473aa166b967d67d31df2c3147363e0a82ef67f90a79e1b678dc75b26b8b5b67d9aafd078d3848cdb6e5a2c1ab748151cc0', '', 'H.Agus Hermawan', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Ag', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(33, 2, 'STAI005', '9fc2715f04bfbd0228d43ab03857ca5d0d6577c63c864173aa8ec5984eb3cea0b0a943274665aecec7a1bc4edc41673c0f57a11bccbd91e2178925109a9397ce', '', 'Asep Sudrajat', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.H', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(34, 2, 'STAI006', 'd589f2358a9ef1afc45980e234aa4c709288387fa0d3de5c41b6a4cb1177d4d5be8dd1bfae014f5e9066dce2fc82dc91657449ce690abc7248c18f4a29b2fd45', '', 'Budi Solihin', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.A', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(35, 2, 'STAI007', '05baa060a23aaa279d31acad98c223f140dfca5edf2f35efe6820b2b3d20799af24ec91123756345388fcb8ae363474a22783f4c0783c0af6e66aefe0012082e', '', 'Dadan Rahadian', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Ag.,M.Si', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(36, 2, 'STAI008', 'd5bc8e4a77173524dc4809407de7334c3ec66dd9d318ee62b6eb2df1c1b18757c44e0a903fb42119bc24fc5be341e2524cf78dcf9731bd5b89fbcaf010ba910a', '', 'Dani Setiawan', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(37, 2, 'STAI010', '311d38d6d18a11047140a366f8d91d13df27e9e9aba9ff8dcaa702e1c8f03c23652d6cb9545395f499ad53b57db839dc793bf0c5e4f3a5d57fcec8445a706697', '', 'Eef Saefullah', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Ag', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(38, 2, 'STAI011', '67879d5c41e060998a6ecdfd20ebb74b449b4c71812d50762e717c04c4b9ea2ce90c86a3fe7b300e23abeedf40b98bffc28427d4db0d9a1dfcfbbb3d83e21716', '', 'Iwan Hermawan', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.M', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(39, 2, 'STAI012', '4ae0024b245608e2fe0001379848568bfa9272cd3611bcf0318cacfb85040344bf27a95a0667334b2bc0385126b873464d1605308349fdb2d6a72e4ac5c43235', '', 'Nanang Sobarna', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.E.Sy', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(40, 2, 'STAI013', 'a626a2076fc05a3856182cf3418f4062762151522573831b0e50f027d7a51f60fabddaae5945e725ef2784a4a29314d597b8c19f6854d4b9464f0719b8341406', '', 'Rahwan', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Ag.,M.Pd.I', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(41, 2, 'STAI014', 'a5074447e5bd30724fef114e397f62d70f359531ca5842137b6408185185308438b277807abfcb14d5d79c1d99c5d93df7573fa566054c593ca8cbeeb410054c', '', 'Solahudin Kamil', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.H.I', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(42, 2, 'STAI015', '8c793df88e6038ae3a64bec0c311115bf1f58346dd706565e49c0e60ce42669f108bb1d1abae24d7caf331dbba698dce47ee05440d64bdef0e9b7499253daa52', '', 'Sukmana', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.Ag.,M.Ag', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(43, 2, 'STAI016', 'c4d90b2b271e7fa7dfe5c6eb9c970e254fd6dedcfaff4cedf0a3d3aa869e39d89192a5e1e03d27e2442f7d414f5fa580832216680750aa21a77390af3563a5c2', '', 'Tika Kartika', 213131, '60202', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',S.E', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg'),
(44, 2, 'STAI045', 'a6e96abe1de8ba896bd27499618cb7277b7d28d343d5ca742e47b5719a8cbd9629f90e811f58a72d201db88cc6507a3e818430f4876f52ab758bda8763ac7c3b', '', 'Usep Diki Hadian', 213131, '86208', '', '', '', '0000-00-00', '', 'ISLAM', '', '', '', '', NULL, '', '', '', ',M.Pd', '0', '', '', '0', '0', '0000-00-00', '0', '0', 'Y', 'no foto.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `dropdownsystem`
--

CREATE TABLE `dropdownsystem` (
  `ID_ds` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  `nama` varchar(100) CHARACTER SET latin1 NOT NULL,
  `menu_order` int(11) NOT NULL,
  `url` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `dropdownsystem`
--

INSERT INTO `dropdownsystem` (`ID_ds`, `id_group`, `nama`, `menu_order`, `url`) VALUES
(1, 2, '01 Kalender Akademik', 1, '?page=kalenderakademik'),
(2, 2, '02 Penjadwalan Kuliah', 2, '?page=jadwalkuliah'),
(3, 2, '03 Registrasi Ulang Mahasiswa', 3, '?page=registrasiulangmhsw'),
(4, 4, '01 Absen Kuliah', 1, '?page=dosenabsenkuliah'),
(5, 4, '02 Nilai Mahasiswa', 2, '?page=dosennilaimahasiswa'),
(6, 2, '04 KRS Mahasiswa', 4, '?page=akademikkrs'),
(7, 2, '05 Input Nilai Mahasiswa', 5, '?page=akademikinputnilaimhs'),
(8, 2, '06 KHS Mahasiswa', 6, '?page=akademikkhsmhs'),
(9, 2, '07 Transkrip Nilai Mahasiswa', 7, '?page=akademiktranskripnilai'),
(10, 8, '01 Identitas Institusi', 1, '?page=masterinstitusi'),
(11, 8, '02 Program Studi', 2, '?page=masterprodi'),
(12, 8, '03 Program', 3, '?page=masterprogram'),
(13, 8, '04 Kampus', 4, '?page=masterkampus'),
(14, 8, '05 Ruangan', 5, '?page=masterruangan'),
(15, 8, '06 Matakuliah', 6, '?page=mastermatakuliah'),
(16, 8, '07 Dosen', 7, '?page=masterdosen'),
(17, 8, '08 Mahasiswa', 8, '?page=mastermahasiswa'),
(18, 10, '01 Admin Administrator', 1, '?page=adminadministrator'),
(19, 10, '02 Admin Akademik', 2, '?page=adminakademik'),
(21, 57, '01 MSMHS', 1, '?page=epsbedmsmhs'),
(22, 57, '02 TBKMK', 2, '?page=epsbedttbkmk'),
(23, 57, '03 TBBNL', 3, '?page=epsbedtbbnl'),
(24, 57, '04 TRAKD', 4, '?page=epsbedtrakd'),
(25, 57, '05 TRNLM', 5, '?page=epsbedtrnlm'),
(26, 1, '01 Kalender Akademik', 1, '?page=baakademikkalender'),
(27, 1, '02 Penjadwalan Kuliah', 2, '?page=baakademikjadwal'),
(28, 1, '03 Registrasi Ulang Mahasiswa', 3, '?page=baakademikregulang'),
(29, 1, '04 KRS Mahasiswa', 4, '?page=baakademikjadwalkrs'),
(30, 1, '05 Input Nilai Mahasiswa', 5, '?page=bakademikinputnilaimhs'),
(31, 1, '06 KHS Mahasiswa', 6, '?page=bakademikkhsmhs'),
(32, 1, '07 Transkrip Nilai Mahasiswa', 7, '?page=bakademiktranskripnilai'),
(33, 8, '01 Matakuliah', 1, '?page=baakademikmastermatakuliah'),
(34, 8, '02 Mahasiswa', 2, '?page=baakademikmastermahasiswa'),
(35, 4, '01 Data Dosen', 1, '?page=dosendata'),
(36, 4, '02 Input Nilai Mahasiswa', 2, '?page=doseninputnilaimhsw'),
(37, 7, '01 Data Mahasiswa', 1, '?page=mahasiswadata'),
(38, 7, '02 KRS Mahasiswa', 2, '?page=mahasiswakrs'),
(40, 7, '03 KHS Mahasiswa', 3, '?page=mahasiswakhs'),
(41, 7, '04 Transkrip Nilai', 4, '?page=mahasiswatranskrip'),
(45, 4, '03 Upload Materi', 3, '?page=1f56234e-4361-4706-bb5a-91d3101bbdb6'),
(44, 59, '01 Download', 1, '?page=50f9e899-0d4d-4b7b-a518-fb18bc430926'),
(46, 7, '05 Download Materi', 5, '?page=24fd7148-9843-46d6-bb33-5b1d86b5a172');

-- --------------------------------------------------------

--
-- Struktur dari tabel `epsbed`
--

CREATE TABLE `epsbed` (
  `ID` int(11) NOT NULL,
  `Nama` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Ket` varchar(50) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `epsbed`
--

INSERT INTO `epsbed` (`ID`, `Nama`, `Ket`) VALUES
(15, 'TBKMK_20152.DBF', 'tbkmk'),
(21, 'TBBNL_20151.DBF', 'tbbnl'),
(24, 'MSMHS_20151.DBF', 'msmhs'),
(23, 'TRNLM_20151.DBF', 'trnlm'),
(22, 'TRAKD_20151.DBF', 'trakd');

-- --------------------------------------------------------

--
-- Struktur dari tabel `error`
--

CREATE TABLE `error` (
  `id` int(11) NOT NULL,
  `tabel` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `text` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `error`
--

INSERT INTO `error` (`id`, `tabel`, `text`) VALUES
(1, 'Group Modul', '1. Pengisian form berurutan sesuai dengan parent ID modul.2. Jika Terjadi Kesalahan yang tidak anda ketahui silakan hubungi administrator anda.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `fileupload`
--

CREATE TABLE `fileupload` (
  `File_ID` bigint(20) NOT NULL,
  `Nama_File` varchar(255) NOT NULL,
  `File` varchar(100) NOT NULL,
  `Level_ID` int(11) NOT NULL,
  `Uplouder` varchar(100) NOT NULL,
  `TglInput` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `fileupload`
--

INSERT INTO `fileupload` (`File_ID`, `Nama_File`, `File`, `Level_ID`, `Uplouder`, `TglInput`) VALUES
(19, 'Kalender Akademik 2015/2016', 'Kalender_Akademik_Genap_2015_2016.rar', 1, '', '2016-02-21 13:55:18'),
(20, 'PROSEDUR PENGISISAN KRS', 'Prosedur Pengisian KRS (STAI_SAS).zip', 1, '', '2016-03-02 13:45:47');

-- --------------------------------------------------------

--
-- Struktur dari tabel `groupmodul`
--

CREATE TABLE `groupmodul` (
  `id_group` int(10) NOT NULL,
  `relasi_modul` int(10) NOT NULL,
  `nama` varchar(100) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `groupmodul`
--

INSERT INTO `groupmodul` (`id_group`, `relasi_modul`, `nama`) VALUES
(1, 1, 'Ba Akademik'),
(2, 2, 'Akademik'),
(4, 4, 'Dosen'),
(7, 7, 'Mahasiswa'),
(8, 8, 'Master'),
(10, 10, 'Admin'),
(57, 12, 'EPSBED'),
(59, 11, 'Download');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hakmodul`
--

CREATE TABLE `hakmodul` (
  `ID_hm` int(11) NOT NULL,
  `id_level` int(11) NOT NULL,
  `ID_ds` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `hakmodul`
--

INSERT INTO `hakmodul` (`ID_hm`, `id_level`, `ID_ds`) VALUES
(1, 1, 1),
(2, 1, 2),
(15, 1, 16),
(4, 1, 3),
(5, 1, 6),
(6, 1, 7),
(7, 1, 8),
(8, 1, 9),
(9, 1, 10),
(10, 1, 11),
(11, 1, 12),
(12, 1, 13),
(13, 1, 14),
(14, 1, 15),
(16, 1, 17),
(17, 1, 18),
(18, 1, 19),
(19, 1, 20),
(20, 1, 21),
(21, 1, 22),
(22, 1, 23),
(23, 1, 24),
(24, 1, 25),
(25, 3, 26),
(26, 3, 27),
(27, 3, 28),
(28, 3, 29),
(29, 3, 30),
(30, 3, 31),
(31, 3, 32),
(32, 3, 33),
(33, 3, 34),
(34, 2, 35),
(35, 2, 36),
(36, 4, 37),
(37, 4, 38),
(38, 4, 39),
(39, 4, 40),
(40, 4, 41),
(42, 1, 44),
(43, 2, 45),
(44, 4, 46);

-- --------------------------------------------------------

--
-- Struktur dari tabel `hari`
--

CREATE TABLE `hari` (
  `id` int(11) NOT NULL,
  `hari` varchar(10) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `hari`
--

INSERT INTO `hari` (`id`, `hari`) VALUES
(1, 'Senin'),
(2, 'Selasa'),
(3, 'Rabu'),
(4, 'Kamis'),
(5, 'Jumat'),
(6, 'Sabtu'),
(7, 'Minggu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hidup`
--

CREATE TABLE `hidup` (
  `Hidup` char(3) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `hidup`
--

INSERT INTO `hidup` (`Hidup`, `Nama`, `NA`) VALUES
('1', 'Masih Hidup', 'N'),
('2', 'Sudah Meninggal', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `identitas`
--

CREATE TABLE `identitas` (
  `ID` int(11) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `KodeHukum` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `Nama_Identitas` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `TglMulai` date NOT NULL DEFAULT '0000-00-00',
  `Alamat1` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Kota` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePos` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Fax` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Email` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Website` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NoAkta` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TglAkta` date DEFAULT NULL,
  `NoSah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TglSah` date DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `identitas`
--

INSERT INTO `identitas` (`ID`, `Identitas_ID`, `KodeHukum`, `Nama_Identitas`, `TglMulai`, `Alamat1`, `Kota`, `KodePos`, `Telepon`, `Fax`, `Email`, `Website`, `NoAkta`, `TglAkta`, `NoSah`, `TglSah`, `Aktif`) VALUES
(25, 213131, '-', 'Sekolah Tinggi Agama Islam (STAI) Sebelas April Sumedang', '0000-00-00', 'Jl.Angrek Situ No.19 Sumedang Utara - Jawa Barat', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE `jabatan` (
  `Jabatan_ID` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`Jabatan_ID`, `Nama`, `Def`, `NA`) VALUES
('A', 'Tenaga Pengajar', 'N', 'N'),
('B', 'Asisten Ahli', 'N', 'N'),
('C', 'Lektor', 'N', 'N'),
('D', 'Lektor Kepala', 'N', 'N'),
('E', 'Guru Besar', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatandikti`
--

CREATE TABLE `jabatandikti` (
  `JabatanDikti_ID` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jabatandikti`
--

INSERT INTO `jabatandikti` (`JabatanDikti_ID`, `Nama`, `Def`, `NA`) VALUES
('01', 'AAM', 'N', 'N'),
('02', 'AA', 'N', 'N'),
('03', 'LMu', 'N', 'N'),
('04', 'LMa', 'N', 'N'),
('05', 'L', 'N', 'N'),
('06', 'LKM', 'N', 'N'),
('07', 'LK', 'N', 'N'),
('08', 'GBM', 'N', 'N'),
('09', 'GB', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE `jadwal` (
  `Jadwal_ID` bigint(20) NOT NULL,
  `Tahun_ID` int(5) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Program_ID` int(5) NOT NULL,
  `Kode_Mtk` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `Ruang_ID` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `Kelas` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Dosen_ID` int(11) NOT NULL,
  `Hari` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `Jam_Mulai` time NOT NULL DEFAULT '00:00:00',
  `Jam_Selesai` time NOT NULL DEFAULT '00:00:00',
  `UTSTgl` date NOT NULL,
  `UTSHari` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `UTSMulai` time NOT NULL,
  `UTSSelesai` time NOT NULL,
  `UTSRuang` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `UASTgl` date NOT NULL,
  `UASHari` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `UASMulai` time NOT NULL,
  `UASSelesai` time NOT NULL,
  `UASRuang` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `JumlahMhsw` int(11) NOT NULL,
  `Kapasitas` int(11) NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`Jadwal_ID`, `Tahun_ID`, `Identitas_ID`, `Jurusan_ID`, `Program_ID`, `Kode_Mtk`, `Ruang_ID`, `Kelas`, `Dosen_ID`, `Hari`, `Jam_Mulai`, `Jam_Selesai`, `UTSTgl`, `UTSHari`, `UTSMulai`, `UTSSelesai`, `UTSRuang`, `UASTgl`, `UASHari`, `UASMulai`, `UASSelesai`, `UASRuang`, `JumlahMhsw`, `Kapasitas`, `Aktif`) VALUES
(4, 20151, 213131, 86208, 3, 'IA123', '4', '', 5, 'Senin', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(3, 20151, 213131, 86208, 3, 'IA134', '4', '', 7, 'Selasa', '15:30:00', '18:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(6, 20151, 213131, 86208, 3, 'IB125', '4', '', 13, 'Senin', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(7, 20151, 213131, 86208, 3, 'IA125', '4', '', 11, 'Selasa', '12:30:00', '15:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(8, 20152, 213131, 86208, 3, 'IA225', '4', '', 11, 'Kamis', '13:50:00', '16:20:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(9, 20152, 213131, 86208, 3, 'IC221', '4', 'P', 6, 'Senin', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(10, 20151, 213131, 86208, 3, 'IA122', '4', '', 24, 'Rabu', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(11, 20151, 213131, 86208, 3, 'IB124', '4', '', 23, 'Rabu', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(12, 20151, 213131, 86208, 3, 'IA121', '4', '', 9, 'Rabu', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(13, 20151, 213131, 86208, 3, 'IE104', '4', '', 19, 'Senin', '10:00:00', '11:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(14, 20151, 213131, 86208, 3, 'IB121', '4', '', 4, 'Kamis', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(15, 20151, 213131, 86208, 3, 'IB123', '4', '', 21, 'Senin', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(16, 20151, 213131, 86208, 3, '0', '0', '', 22, 'Senin', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(17, 20151, 213131, 86208, 3, 'IB3210', '14', '', 12, 'Senin', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(18, 20151, 213131, 86208, 3, 'IA325', '14', '', 7, 'Senin', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(19, 20151, 213131, 86208, 3, 'IA324', '14', '', 18, 'Selasa', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(20, 20151, 213131, 86208, 3, 'ID321', '14', '', 10, 'Selasa', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(21, 20151, 213131, 86208, 3, 'IC321', '14', '', 6, 'Selasa', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(22, 20151, 213131, 86208, 3, 'IC324', '14', '', 27, 'Rabu', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(23, 20151, 213131, 86208, 3, 'IC322', '14', '', 15, 'Rabu', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(27, 20151, 213131, 86208, 3, 'IB122', '4', '', 14, 'Kamis', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(26, 20151, 213131, 86208, 3, 'IB126', '4', '', 2, 'Kamis', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(29, 20151, 213131, 86208, 3, 'IB329', '14', '', 14, 'Rabu', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(30, 20151, 213131, 86208, 3, '', '0', '', 8, 'Kamis', '13:00:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(31, 20151, 213131, 86208, 3, 'IB328', '14', '', 26, 'Kamis', '16:00:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(32, 20152, 213131, 86208, 3, 'IA226', '4', 'P', 24, 'Senin', '16:00:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(33, 20152, 213131, 86208, 3, 'IA224', '4', 'P', 7, 'Selasa', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(34, 20152, 213131, 86208, 3, 'IB2210', '4', 'P', 26, 'Selasa', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(35, 20152, 213131, 86208, 3, 'IB228', '4', 'P', 4, 'Selasa', '16:00:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(36, 20152, 213131, 86208, 3, 'IB227', '4', 'P', 2, 'Rabu', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(37, 20152, 213131, 86208, 3, 'IC222', '4', 'P', 15, 'Rabu', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(38, 20152, 213131, 86208, 3, 'IB22.9', '4', 'P', 14, 'Rabu', '16:00:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(39, 20152, 213131, 86208, 3, 'IB22.11', '4', 'P', 23, 'Kamis', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(40, 20152, 213131, 86208, 3, 'IB2211', '4', '', 23, 'Kamis', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(41, 20152, 213131, 86208, 3, 'IE421', '4', '', 1, 'Senin', '09:00:00', '11:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(42, 20152, 213131, 86208, 3, 'IC436', '15', 'P', 5, 'Senin', '11:00:00', '13:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(43, 20152, 213131, 86208, 3, 'IE105', '15', 'P', 21, 'Senin', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(44, 20152, 213131, 86208, 3, 'IA424', '15', 'P', 18, 'Senin', '15:30:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(45, 20152, 213131, 86208, 3, 'IC435', '15', 'P', 44, 'Selasa', '11:00:00', '13:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(46, 20152, 213131, 86208, 3, 'IB4210', '15', 'P', 17, 'Selasa', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(47, 20152, 213131, 86208, 3, 'IE422', '15', 'P', 20, 'Kamis', '16:30:00', '18:10:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(48, 20152, 213131, 86208, 3, 'IB4213', '15', 'P', 19, 'Rabu', '13:00:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(49, 20152, 213131, 86208, 3, 'IB4314', '15', 'P', 16, 'Rabu', '15:40:00', '18:10:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(50, 20152, 213131, 86208, 3, 'IB428', '15', 'P', 26, 'Selasa', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(51, 20152, 213131, 86208, 3, 'IB429', '15', 'P', 12, 'Kamis', '13:00:00', '14:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(52, 20152, 213131, 86208, 3, 'IA425', '15', 'P', 7, 'Kamis', '14:40:00', '16:20:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(53, 20152, 213131, 86208, 3, 'IC6313', '17', 'P', 22, 'Senin', '12:10:00', '14:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(54, 20152, 213131, 86208, 3, 'IC6311', '17', 'P', 10, 'Senin', '15:50:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(55, 20152, 213131, 86208, 3, 'IB6319', '17', 'P', 27, 'Selasa', '11:00:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(56, 20152, 213131, 86208, 3, 'IC6215', '17', 'P', 6, 'Selasa', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(57, 20152, 213131, 86208, 3, 'IC6214', '17', '', 28, 'Selasa', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(58, 20152, 213131, 86208, 3, 'IC6312', '17', 'P', 8, 'Rabu', '13:00:00', '14:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(59, 20152, 213131, 86208, 3, 'IB6321', '17', 'P', 24, 'Rabu', '14:40:00', '16:10:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(60, 20152, 213131, 86208, 3, 'IB6220', '17', '', 3, 'Kamis', '13:00:00', '14:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(61, 20152, 213131, 86208, 3, 'IE623', '17', '', 25, 'Kamis', '14:40:00', '16:10:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(62, 20152, 213131, 86208, 3, 'IB229', '4', '', 14, 'Rabu', '16:00:00', '17:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(63, 20151, 213131, 60202, 3, 'D104', '4', '', 38, 'Selasa', '12:30:00', '14:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(64, 20151, 213131, 60202, 3, 'A111', '4', '', 5, 'Selasa', '14:30:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(65, 20151, 213131, 60202, 3, 'A108', '4', '', 35, 'Selasa', '16:10:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(66, 20151, 213131, 60202, 3, 'B100', '4', '', 22, 'Rabu', '13:00:00', '14:20:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(67, 20151, 213131, 60202, 3, 'A109', '4', '', 31, 'Rabu', '14:20:00', '15:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(68, 20151, 213131, 60202, 3, 'C113', '4', '', 17, 'Rabu', '16:00:00', '17:20:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(69, 20151, 213131, 60202, 3, 'A105', '4', '', 43, 'Kamis', '13:00:00', '14:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(70, 20151, 213131, 60202, 3, 'A100', '4', '', 23, 'Kamis', '14:20:00', '15:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(71, 20151, 213131, 60202, 3, 'A104', '4', '', 34, 'Jumat', '13:00:00', '14:20:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(72, 20151, 213131, 60202, 3, 'D105', '4', '', 24, 'Jumat', '14:20:00', '15:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(73, 20151, 213131, 60202, 3, 'A112', '4', '', 40, 'Jumat', '16:00:00', '17:20:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(74, 20152, 213131, 60202, 3, 'A101', '4', '', 34, 'Senin', '07:30:00', '09:45:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(75, 20152, 213131, 60202, 3, 'E106', '4', '', 23, 'Senin', '09:45:00', '11:15:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(76, 20152, 213131, 60202, 3, 'A107', '4', '', 23, 'Senin', '13:00:00', '14:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(77, 20152, 213131, 60202, 3, 'C114', '4', '', 1, 'Senin', '14:30:00', '16:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(78, 20152, 213131, 60202, 3, 'A103', '4', '', 41, 'Kamis', '08:00:00', '10:15:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(79, 20152, 213131, 60202, 3, 'B103', '4', '', 36, 'Kamis', '10:15:00', '11:45:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(80, 20152, 213131, 60202, 3, 'A110', '4', '', 31, 'Kamis', '13:00:00', '14:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(81, 20152, 213131, 60202, 3, 'B101', '4', '', 35, 'Kamis', '13:00:00', '14:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(82, 20152, 213131, 60202, 3, 'IC435', '4', '', 37, 'Jumat', '08:00:00', '09:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(83, 20152, 213131, 60202, 3, 'A102', '4', '', 40, 'Jumat', '09:30:00', '11:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(84, 20152, 213131, 60202, 3, 'D100', '4', '', 39, 'Jumat', '13:00:00', '14:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(85, 20152, 213131, 60202, 3, 'B102', '4', '', 28, 'Jumat', '15:30:00', '17:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(86, 20152, 213131, 60202, 3, 'C118', '4', '', 37, 'Jumat', '08:00:00', '09:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(87, 20152, 213131, 60202, 3, 'B115', '14', '', 34, 'Selasa', '08:00:00', '10:15:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(88, 20152, 213131, 60202, 3, 'C101', '14', '', 34, 'Selasa', '10:15:00', '12:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(89, 20152, 213131, 60202, 3, 'B113', '14', '', 39, 'Selasa', '13:00:00', '14:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(90, 20152, 213131, 60202, 3, 'B112', '14', '', 39, 'Jumat', '08:00:00', '09:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(91, 20152, 213131, 60202, 3, 'D113', '14', '', 22, 'Jumat', '09:30:00', '11:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(92, 20152, 213131, 60202, 3, 'B106', '14', '', 17, 'Jumat', '13:00:00', '14:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(93, 20152, 213131, 60202, 3, 'B111', '14', '', 32, 'Jumat', '14:30:00', '16:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(94, 20152, 213131, 60202, 3, 'C115', '14', '', 29, 'Sabtu', '08:00:00', '09:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(95, 20152, 213131, 60202, 3, 'C111', '14', '', 39, 'Sabtu', '09:30:00', '11:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(96, 20152, 213131, 60202, 3, 'C102', '14', '', 33, 'Sabtu', '12:30:00', '14:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(97, 20152, 213131, 60202, 3, 'B114', '14', '', 39, 'Sabtu', '14:00:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(98, 20152, 213131, 60202, 3, 'C119', '15', '', 24, 'Kamis', '08:00:00', '09:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(99, 20152, 213131, 60202, 3, 'D114', '15', '', 33, 'Kamis', '09:30:00', '11:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(100, 20152, 213131, 60202, 3, 'D107', '15', '', 32, 'Jumat', '08:00:00', '09:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(101, 20152, 213131, 60202, 3, 'C108', '15', '', 32, 'Jumat', '09:30:00', '11:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(102, 20152, 213131, 60202, 3, 'B116', '15', '', 34, 'Jumat', '14:00:00', '16:15:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(103, 20152, 213131, 60202, 3, 'C116', '15', '', 38, 'Sabtu', '08:00:00', '09:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(104, 20152, 213131, 60202, 3, 'C117', '15', '', 39, 'Sabtu', '09:30:00', '11:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(105, 20152, 213131, 60202, 3, 'B117', '15', '', 39, 'Sabtu', '11:00:00', '12:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(111, 20151, 213131, 86208, 3, 'IB3212', '14', '', 22, 'Senin', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(110, 20151, 213131, 86208, 3, 'IB5217', '15', '', 27, 'Senin', '13:00:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(112, 20151, 213131, 86208, 3, 'IC333', '15', '', 17, 'Kamis', '15:30:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(113, 20151, 213131, 86208, 3, 'IC331', '14', '', 8, 'Kamis', '13:00:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(114, 20151, 213131, 86208, 3, 'IC527', '15', '', 15, 'Senin', '16:00:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(115, 20151, 213131, 86208, 3, 'ID532', '15', '', 25, 'Selasa', '12:30:00', '15:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(116, 20151, 213131, 86208, 3, 'IC529', '15', '', 24, 'Selasa', '15:30:00', '18:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(117, 20151, 213131, 86208, 3, 'IC538', '15', '', 26, 'Rabu', '12:10:00', '13:50:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(118, 20151, 213131, 86208, 3, 'IB5315', '15', '', 28, 'Rabu', '13:50:00', '15:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(119, 20151, 213131, 86208, 3, 'IB5316', '15', '', 6, 'Rabu', '15:50:00', '17:30:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(120, 20151, 213131, 86208, 3, 'IB5218', '15', '', 3, 'Kamis', '12:30:00', '15:00:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y'),
(121, 20151, 213131, 86208, 3, 'IB7022', '17', '', 28, 'Sabtu', '08:00:00', '09:40:00', '0000-00-00', '', '00:00:00', '00:00:00', '', '0000-00-00', '', '00:00:00', '00:00:00', '', 0, 0, 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jeniskurikulum`
--

CREATE TABLE `jeniskurikulum` (
  `JenisKurikulum_ID` int(11) NOT NULL,
  `Kode` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `Singkatan` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Jurusan_ID` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jeniskurikulum`
--

INSERT INTO `jeniskurikulum` (`JenisKurikulum_ID`, `Kode`, `Singkatan`, `Nama`, `Jurusan_ID`, `Aktif`) VALUES
(1, 'A', NULL, 'Inti', '', 'N'),
(2, 'B', NULL, 'Institusi', '', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenismk`
--

CREATE TABLE `jenismk` (
  `ID` int(11) NOT NULL,
  `JenisMTK_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jenismk`
--

INSERT INTO `jenismk` (`ID`, `JenisMTK_ID`, `Nama`, `Aktif`) VALUES
(1, 'A', 'WAJIB', 'Y'),
(2, 'B', 'PILIHAN', 'Y'),
(3, 'C', 'WAJIB PERMINTAAN', 'Y'),
(4, 'D', 'PILIHAN PERMINTAAN', 'Y'),
(5, 'S', 'TA/SKRIPSI/THESIS/DISERTASI', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenissekolah`
--

CREATE TABLE `jenissekolah` (
  `JenisSekolah_ID` int(11) NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jenissekolah`
--

INSERT INTO `jenissekolah` (`JenisSekolah_ID`, `Nama`) VALUES
(4, 'Yayasan Penabur'),
(5, 'Kristen/Katolik Non Penabur'),
(3, 'Umum'),
(2, 'Negeri'),
(6, 'Luar Negeri'),
(1, 'Madrasah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_ujian`
--

CREATE TABLE `jenis_ujian` (
  `ID` int(1) NOT NULL,
  `jenisjadwal` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(100) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jenis_ujian`
--

INSERT INTO `jenis_ujian` (`ID`, `jenisjadwal`, `nama`) VALUES
(1, 'UTS', 'Ujian Tengah Semester'),
(2, 'UAS', 'Ujian Akhir Semester');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenjang`
--

CREATE TABLE `jenjang` (
  `Jenjang_ID` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Keterangan` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jenjang`
--

INSERT INTO `jenjang` (`Jenjang_ID`, `Nama`, `Keterangan`, `Def`, `NA`) VALUES
('A', 'S3', 'Strata Tiga', 'N', 'N'),
('B', 'S2', 'Strata Dua', 'N', 'N'),
('C', 'S1', 'Strata Satu', 'N', 'N'),
('D', 'D4', 'Diploma 4', 'N', 'N'),
('E', 'D3', 'Diploma 3', 'N', 'N'),
('F', 'D2', 'Diploma 2', 'N', 'N'),
('G', 'D1', 'Diploma 1', 'N', 'N'),
('H', 'SP-1', 'Spesialis Satu', 'N', 'N'),
('I', 'SP-2', 'Spesialis Dua', 'N', 'N'),
('J', 'Profesi', 'Profesi', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE `jurusan` (
  `ID` int(11) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `nama_jurusan` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `jenjang` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `Akreditasi` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaKetua` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `NoSKDikti` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `TglSKDikti` date DEFAULT NULL,
  `NoSKBAN` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `TglSKBAN` date DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jurusan`
--

INSERT INTO `jurusan` (`ID`, `Identitas_ID`, `Jurusan_ID`, `nama_jurusan`, `jenjang`, `Akreditasi`, `NamaKetua`, `NoSKDikti`, `TglSKDikti`, `NoSKBAN`, `TglSKBAN`, `Aktif`) VALUES
(3, 213131, 60202, 'Ekonomi Syariah', 'S1', 'A', 'H. Agus Hermawan, M.Ag', '', '0000-00-00', '', '0000-00-00', 'Y'),
(4, 213131, 86208, 'Pendidikan Agama Islam', 'S1', 'A', 'Drs. Lili Sadeli, M.Pd.I', '', '0000-00-00', '', '0000-00-00', 'Y'),
(8, 213131, 1234567, 'PGMI', 'S1', '', '', NULL, NULL, NULL, NULL, 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusansekolah`
--

CREATE TABLE `jurusansekolah` (
  `JurusanSekolah_ID` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaJurusan` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `NA` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `jurusansekolah`
--

INSERT INTO `jurusansekolah` (`JurusanSekolah_ID`, `Nama`, `NamaJurusan`, `NA`) VALUES
('011', 'SMU', 'IPA', 'N'),
('012', 'SMU', 'IPS', 'N'),
('013', 'SMU', 'A4/BAHASA', 'N'),
('021', 'STM PEMBANGUNAN', 'BANGUNAN GEDUNG', 'N'),
('022', 'STM PEMBANGUNAN', 'BANGUNAN AIR', 'N'),
('023', 'STM PEMBANGUNAN', 'MESIN PRODUKSI', 'N'),
('025', 'STM PEMBANGUNAN', 'LISTRIK INDUSTRI', 'N'),
('024', 'STM PEMBANGUNAN', 'OTOMOTIF', 'N'),
('027', 'STM PEMBANGUNAN', 'ELEKTRO KOMUNIKASI', 'N'),
('031', 'SMEA', 'TATA BUKU', 'N'),
('032', 'SMEA', 'TATA NIAGA', 'N'),
('033', 'SMEA', 'TATA USAHA', 'N'),
('101', 'STM', 'ELEKTRONIKA', 'N'),
('102', 'STM', 'LISTRIK', 'N'),
('103', 'STM', 'MESIN PRODUKSI', 'N'),
('104', 'STM', 'BANGUNAN', 'N'),
('105', 'STM', 'OTOMOTIF', 'N'),
('121', 'SMTP', 'BANGUNAN KAPAL', 'N'),
('122', 'SMTP', 'MESIN KAPAL', 'N'),
('131', 'SMTP', 'AVIONIKA', 'N'),
('132', 'SMTP', 'LISTRIK & INSTRUMEN', 'N'),
('133', 'SMTP', 'MOTOR & RANGKA', 'N'),
('350', 'SMEA PEMBANGUNAN', 'EKONOMI', 'N'),
('014', 'SMU', 'A1', 'N'),
('015', 'SMU', 'A2', 'N'),
('016', 'SMU', 'A3', 'N'),
('161', 'SPG', 'SD', 'N'),
('162', 'SPG', 'TK', 'N'),
('999', 'SMA LUAR NEGERI', '', 'N'),
('041', 'SMF', 'FARMASI', 'N'),
('042', 'SA KES', 'ANALISI KESEHATAN', 'N'),
('034', 'SMEA', 'SEKRETARIS', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kampus`
--

CREATE TABLE `kampus` (
  `ID` int(11) NOT NULL,
  `Identitas_ID` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `Kampus_ID` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Alamat` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Kota` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Fax` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `kampus`
--

INSERT INTO `kampus` (`ID`, `Identitas_ID`, `Kampus_ID`, `Nama`, `Alamat`, `Kota`, `Telepon`, `Fax`, `Aktif`) VALUES
(1, '213131', 'K1', 'STAI Sebelas April Sumedanng', 'Jl.Angkrek Situ No.19 Sumedang', '', '', '', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelompokmtk`
--

CREATE TABLE `kelompokmtk` (
  `ID` int(1) NOT NULL,
  `KelompokMtk_ID` varchar(4) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `kelompokmtk`
--

INSERT INTO `kelompokmtk` (`ID`, `KelompokMtk_ID`, `Nama`, `Aktif`) VALUES
(1, 'A', 'MPK-Pengembangan Kepribadian', 'Y'),
(2, 'B', 'MKK-KEILMUAN DAN KETERAMPILAN', 'Y'),
(3, 'C', 'MKB-KEAHLIAN BERKARYA', 'Y'),
(4, 'D', 'MPB-PERILAKU BERKARYA', 'Y'),
(5, 'E', 'MBB-BERKEHIDUPAN BERMASYARAKAT', 'Y'),
(6, 'F', 'MKU/MKDU', 'Y'),
(7, 'G', 'MKDK', 'Y'),
(8, 'H', 'MKK', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `krs`
--

CREATE TABLE `krs` (
  `KRS_ID` bigint(20) NOT NULL,
  `NIM` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Tahun_ID` int(5) NOT NULL,
  `Jadwal_ID` bigint(20) NOT NULL DEFAULT '0',
  `Kode_mtk` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `SKS` int(1) NOT NULL DEFAULT '0',
  `Tugas1` int(11) NOT NULL DEFAULT '0',
  `Tugas2` int(11) NOT NULL DEFAULT '0',
  `Presensi` int(11) NOT NULL DEFAULT '0',
  `UTS` int(11) NOT NULL DEFAULT '0',
  `UAS` int(11) NOT NULL DEFAULT '0',
  `GradeNilai` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '-',
  `BobotNilai` decimal(4,2) NOT NULL DEFAULT '0.00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `krs`
--

INSERT INTO `krs` (`KRS_ID`, `NIM`, `Tahun_ID`, `Jadwal_ID`, `Kode_mtk`, `SKS`, `Tugas1`, `Tugas2`, `Presensi`, `UTS`, `UAS`, `GradeNilai`, `BobotNilai`) VALUES
(20, '201521001', 20151, 69, 'A105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(21, '201521001', 20151, 73, 'A112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(19, '201521001', 20151, 65, 'A108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(22, '201521001', 20151, 66, 'B100', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(23, '201521001', 20151, 70, 'A100', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(24, '201521001', 20151, 63, 'D104', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(25, '201521001', 20151, 67, 'A109', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(26, '201521001', 20151, 71, 'A104', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(27, '201521001', 20151, 64, 'A111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(28, '201521001', 20151, 68, 'C113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(29, '201521001', 20151, 72, 'D105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(32, '201511007', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(33, '201511007', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(34, '201511007', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(35, '201511007', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(36, '201511007', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(37, '201511007', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(38, '201511007', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(39, '201511007', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(40, '201511007', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(41, '201511007', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(42, '201511007', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(43, '201411038', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(44, '201411038', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(45, '201411038', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(46, '201411038', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(47, '201411038', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(48, '201411038', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(49, '201411038', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(50, '201411038', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(51, '201411038', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(52, '201411038', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(53, '201411038', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(54, '201511032', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(55, '201511032', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(56, '201511032', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(57, '201511032', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(58, '201511032', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(59, '201511032', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(60, '201511032', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(61, '201511032', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(62, '201511032', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(63, '201511032', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(64, '201511032', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(65, '201511015', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(66, '201511015', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(67, '201511015', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(68, '201511015', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(69, '201511015', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(70, '201511015', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(71, '201511015', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(72, '201511015', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(73, '201511015', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(74, '201511015', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(75, '201511015', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(76, '201511011', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(77, '201511011', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(78, '201511011', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(79, '201511011', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(80, '201511011', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(81, '201511011', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(82, '201511011', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(83, '201511011', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(84, '201511011', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(85, '201511011', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(86, '201511011', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(87, '201511031', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(88, '201511031', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(89, '201511031', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(90, '201511031', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(91, '201511031', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(92, '201511031', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(93, '201511031', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(94, '201511031', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(95, '201511031', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(96, '201511031', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(97, '201511031', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(98, '201511030', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(99, '201511030', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(100, '201511030', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(101, '201511030', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(102, '201511030', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(103, '201511030', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(104, '201511030', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(105, '201511030', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(106, '201511030', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(107, '201511030', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(108, '201511030', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(109, '201511038', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(110, '201511038', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(111, '201511038', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(112, '201511038', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(113, '201511038', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(114, '201511038', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(115, '201511038', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(116, '201511038', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(117, '201511038', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(118, '201511038', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(119, '201511038', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(120, '201511008', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(121, '201511008', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(122, '201511008', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(123, '201511008', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(124, '201511008', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(125, '201511008', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(126, '201511008', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(127, '201511008', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(128, '201511008', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(129, '201511008', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(130, '201511008', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(131, '201511024', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(132, '201511024', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(133, '201511024', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(134, '201511024', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(135, '201511024', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(136, '201511024', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(137, '201511024', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(138, '201511024', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(139, '201511024', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(140, '201511024', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(141, '201511024', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(142, '201511029', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(143, '201511029', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(144, '201511029', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(145, '201511029', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(146, '201511029', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(147, '201511029', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(148, '201511029', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(149, '201511029', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(150, '201511029', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(151, '201511029', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(152, '201511029', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(153, '201411070', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(154, '201411070', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(155, '201411070', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(156, '201411070', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(157, '201411070', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(158, '201411070', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(159, '201411070', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(160, '201411070', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(161, '201411070', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(162, '201411070', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(163, '201411070', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(164, '201411018', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(165, '201411018', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(166, '201411018', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(167, '201411018', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(168, '201411018', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(169, '201411018', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(170, '201411018', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(171, '201411018', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(172, '201411018', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(173, '201411018', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(174, '201411018', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(175, '201511003', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(176, '201511003', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(177, '201511003', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(178, '201511003', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(179, '201511003', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(180, '201511003', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(181, '201511003', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(182, '201511003', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(183, '201511003', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(184, '201511003', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(185, '201511003', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(186, '201511026', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(187, '201511026', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(188, '201511026', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(189, '201511026', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(190, '201511026', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(191, '201511026', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(192, '201511026', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(193, '201511026', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(194, '201511026', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(195, '201511026', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(196, '201511026', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(198, '201511037', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(199, '201511037', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(200, '201511037', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(201, '201511037', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(202, '201511037', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(203, '201511037', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(204, '201511037', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(205, '201511037', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(206, '201511037', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(207, '201511037', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(208, '201511037', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(209, '201511033', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(210, '201511033', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(211, '201511033', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(212, '201511033', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(213, '201511033', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(214, '201511033', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(215, '201511033', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(216, '201511033', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(217, '201511033', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(218, '201511033', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(219, '201511033', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(220, '201511009', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(221, '201511009', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(222, '201511009', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(223, '201511009', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(224, '201511009', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(225, '201511009', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(226, '201511009', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(227, '201511009', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(228, '201511009', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(229, '201511009', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(230, '201511009', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(231, '201511018', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(232, '201511018', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(233, '201511018', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(234, '201511018', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(235, '201511018', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(236, '201511018', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(237, '201511018', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(238, '201511018', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(239, '201511018', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(240, '201511018', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(241, '201511018', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(242, '201511010', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(243, '201511010', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(244, '201511010', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(245, '201511010', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(246, '201511010', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(247, '201511010', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(248, '201511010', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(249, '201511010', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(250, '201511010', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(251, '201511010', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(252, '201511010', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(253, '201521005', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(254, '201521005', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(255, '201521005', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(256, '201521005', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(257, '201521005', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(258, '201521005', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(259, '201521005', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(260, '201521005', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(261, '201521005', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(262, '201521005', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(263, '201521005', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(264, '201521010', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(265, '201521010', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(266, '201521010', 20152, 84, 'D100', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(267, '201521010', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(268, '201521010', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(269, '201521010', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(270, '201521010', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(271, '201521010', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(272, '201521010', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(273, '201521010', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(274, '201521010', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(275, '201521010', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(276, '201311084', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(277, '201311084', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(278, '201311084', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(279, '201311084', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(280, '201311084', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(281, '201311084', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(282, '201311084', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(283, '201311084', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(284, '201311084', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(285, '201311056', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(286, '201311056', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(287, '201311056', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(288, '201311056', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(289, '201311056', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(290, '201311056', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(291, '201311056', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(292, '201311056', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(293, '201311056', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(294, '201311052', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(295, '201311052', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(296, '201311052', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(297, '201311052', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(298, '201311052', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(299, '201311052', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(300, '201311052', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(301, '201311052', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(302, '201311052', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(329, '201521009', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(330, '201521009', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(331, '201521009', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(332, '201521009', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(333, '201521009', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(334, '201521009', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(335, '201521009', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(336, '201521009', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(337, '201521009', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(338, '201411091', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(339, '201411091', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(340, '201411091', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(341, '201411091', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(342, '201411091', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(326, '201521009', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(327, '201521009', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1971, '201411003', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(343, '201411091', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(344, '201411091', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(345, '201411091', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(346, '201411091', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(347, '201411091', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(350, '201411020', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(349, '201411091', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(351, '201411020', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(352, '201411020', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(353, '201411020', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(354, '201411020', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(355, '201411020', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(356, '201411020', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(357, '201411020', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(358, '201411020', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(359, '201411020', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(360, '201411020', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(361, '201411064', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(362, '201411064', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(363, '201411064', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(364, '201411064', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(365, '201411064', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(366, '201411064', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(367, '201411064', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(368, '201411064', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(369, '201411064', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(370, '201411064', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(371, '201411064', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(372, '201311099', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(373, '201311099', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(374, '201311099', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(375, '201311099', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(376, '201311099', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(377, '201311099', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(378, '201311099', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(379, '201311099', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(380, '201311099', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(381, '201311072', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(382, '201311072', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(383, '201311072', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(384, '201311072', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(385, '201311072', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(386, '201311072', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(387, '201311072', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(388, '201311072', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(389, '201311072', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(390, '201311037', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(391, '201311037', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(392, '201311037', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(393, '201311037', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(394, '201311037', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(395, '201311037', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(396, '201311037', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(397, '201311037', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(398, '201311037', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(399, '201421005', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(400, '201421005', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(401, '201421005', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(402, '201421005', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(403, '201421005', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(404, '201421005', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(405, '201421005', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(406, '201421005', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(407, '201421005', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(408, '201421005', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(409, '201421005', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(410, '201411069', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(411, '201411069', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(412, '201411069', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(413, '201411069', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(414, '201411069', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(415, '201411069', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(416, '201411069', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(417, '201411069', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(418, '201411069', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(419, '201411069', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(420, '201411069', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(421, '201411030', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(422, '201411030', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(423, '201411030', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(424, '201411030', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(425, '201411030', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(426, '201411030', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(427, '201411030', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(428, '201411030', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(429, '201411030', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(430, '201411030', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(431, '201411030', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(432, '201421008', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(433, '201421008', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(434, '201421008', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(435, '201421008', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(436, '201421008', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(437, '201421008', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(438, '201421008', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(439, '201421008', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(440, '201421008', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(441, '201421008', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(442, '201421008', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(443, '201511016', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(444, '201511016', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(445, '201511016', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(446, '201511016', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(447, '201511016', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(448, '201511016', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(449, '201511016', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(450, '201511016', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(451, '201511016', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(452, '201511016', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(453, '201511016', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(454, '201511021', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(455, '201511021', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(456, '201511021', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(457, '201511021', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(458, '201511021', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(459, '201511021', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(460, '201511021', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(461, '201511021', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(462, '201511021', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(463, '201511021', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(464, '201511021', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(465, '201511022', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(466, '201511022', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(467, '201511022', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(468, '201511022', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(469, '201511022', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(470, '201511022', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(471, '201511022', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(472, '201511022', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(473, '201511022', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(474, '201511022', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(475, '201511022', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(476, '201311023', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(477, '201311023', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(478, '201311023', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(479, '201311023', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(480, '201311023', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(481, '201311023', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(482, '201311023', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(483, '201311023', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(484, '201311023', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(485, '201311045', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(486, '201311045', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(487, '201311045', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(488, '201311045', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(489, '201311045', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(490, '201311045', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(491, '201311045', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(492, '201311045', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(493, '201311045', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(494, '201311033', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(495, '201311033', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(496, '201311033', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(497, '201311033', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(498, '201311033', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(499, '201311033', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(500, '201311033', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(501, '201311033', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(502, '201311033', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(503, '201511001', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(504, '201511001', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(505, '201511001', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(506, '201511001', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(507, '201511001', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(508, '201511001', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(509, '201511001', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(510, '201511001', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(511, '201511001', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(512, '201511001', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(513, '201511001', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(514, '201421002', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(515, '201421002', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(516, '201421002', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(517, '201421002', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(518, '201421002', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(519, '201421002', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(520, '201421002', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(521, '201421002', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(522, '201421002', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(523, '201421002', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(524, '201421002', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(525, '201513039', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(526, '201513039', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(527, '201513039', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(528, '201513039', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(529, '201513039', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(530, '201513039', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(531, '201513039', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(532, '201513039', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(533, '201411007', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(534, '201411007', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(535, '201411007', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(536, '201411007', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(537, '201411007', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(538, '201411007', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(539, '201411007', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(540, '201411007', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(541, '201411007', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(542, '201411007', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(543, '201411007', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(544, '201411084', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(545, '201411084', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(546, '201411084', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(547, '201411084', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(548, '201411084', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(549, '201411084', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(550, '201411084', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(551, '201411084', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(552, '201411084', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(553, '201411084', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(554, '201411084', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(555, '201411060', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(556, '201411060', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(557, '201411060', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(558, '201411060', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(559, '201411060', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(560, '201411060', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(561, '201411060', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(562, '201411060', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(563, '201411060', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(564, '201411060', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(565, '201411060', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(566, '201421001', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(567, '201421001', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(568, '201421001', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(569, '201421001', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(570, '201421001', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(571, '201421001', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(572, '201421001', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(573, '201421001', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(574, '201421001', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(575, '201421001', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(576, '201421001', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(577, '201411053', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(578, '201411053', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(579, '201411053', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(580, '201411053', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(581, '201411053', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(582, '201411053', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(583, '201411053', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(584, '201411053', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(585, '201411053', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(586, '201411053', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(587, '201411053', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(588, '201511020', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(589, '201511020', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(590, '201511020', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(591, '201511020', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(592, '201511020', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(593, '201511020', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(594, '201511020', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(595, '201511020', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(596, '201511020', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(597, '201511020', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(598, '201511020', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(599, '201311087', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(600, '201311087', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(601, '201311087', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(602, '201311087', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(603, '201311087', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(604, '201311087', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(605, '201311087', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(606, '201311087', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(607, '201311087', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(608, '201411009', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(609, '201411009', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(610, '201411009', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(611, '201411009', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(612, '201411009', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(613, '201411009', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(614, '201411009', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(615, '201411009', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(616, '201411009', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(617, '201411009', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(618, '201411009', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(619, '201411003', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(620, '201411003', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(621, '201411003', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(622, '201411003', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(623, '201411003', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(624, '201411003', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(625, '201411003', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(626, '201411003', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(627, '201411003', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(628, '201411003', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(629, '201411003', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(631, '201313006', 20152, 99, 'D114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(632, '201313006', 20152, 103, 'C116', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(633, '201313006', 20152, 100, 'D107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(634, '201313006', 20152, 104, 'C117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(635, '201313006', 20152, 101, 'C108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(636, '201313006', 20152, 105, 'B117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(637, '201313006', 20152, 98, 'C119', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(638, '201313006', 20152, 102, 'B116', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(639, '201521011', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(640, '201521011', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(641, '201521011', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(642, '201521011', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(643, '201521011', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(644, '201521011', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(645, '201521011', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(646, '201521011', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(648, '201521011', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(649, '201521011', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(650, '201521011', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(651, '201312021', 20152, 99, 'D114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(652, '201312021', 20152, 103, 'C116', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(653, '201312021', 20152, 100, 'D107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(654, '201312021', 20152, 104, 'C117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(655, '201312021', 20152, 101, 'C108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(656, '201312021', 20152, 105, 'B117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(657, '201312021', 20152, 98, 'C119', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(658, '201312021', 20152, 102, 'B116', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(659, '201311042', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(660, '201311042', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(661, '201311042', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(662, '201311042', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(663, '201311042', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(664, '201311042', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(665, '201311042', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(666, '201311042', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(667, '201311042', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(668, '201523001', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(669, '201523001', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(670, '201523001', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(671, '201523001', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(672, '201523001', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(673, '201523001', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(674, '201523001', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(675, '201523001', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(676, '201523001', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(677, '201523001', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(678, '201523001', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(679, '201421006', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(680, '201421006', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(681, '201421006', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(682, '201421006', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(683, '201421006', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(684, '201421006', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(685, '201421006', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(686, '201421006', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(687, '201421006', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(688, '201421006', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(689, '201421006', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(690, '201311005', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(691, '201311005', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(692, '201311005', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(693, '201311005', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(694, '201311005', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(695, '201311005', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(696, '201311005', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(697, '201311005', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(698, '201311005', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(699, '201311022', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(700, '201311022', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(701, '201311022', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(702, '201311022', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(703, '201311022', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(704, '201311022', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(705, '201311022', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(706, '201311022', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(707, '201311022', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(708, '201411078', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(709, '201411078', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(710, '201411078', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(711, '201411078', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(712, '201411078', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(713, '201411078', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(714, '201411078', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(715, '201411078', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(716, '201411078', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(717, '201411078', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(718, '201411078', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(719, '201311106', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(720, '201311106', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(721, '201311106', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(722, '201311106', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(723, '201311106', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(724, '201311106', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(725, '201311106', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(726, '201311106', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(727, '201311106', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(744, '201311095', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(745, '201311095', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(746, '201311095', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(742, '201311095', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(743, '201311095', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(740, '201311095', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(741, '201311095', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(747, '201311095', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(748, '201311095', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(749, '201312020', 20152, 98, 'C119', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(750, '201312020', 20152, 102, 'B116', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(751, '201312020', 20152, 99, 'D114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(752, '201312020', 20152, 103, 'C116', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(753, '201312020', 20152, 100, 'D107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(754, '201312020', 20152, 104, 'C117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(755, '201312020', 20152, 101, 'C108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(756, '201312020', 20152, 105, 'B117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(757, '201511017', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(758, '201511017', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(759, '201511017', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(760, '201511017', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(761, '201511017', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(762, '201511017', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(763, '201511017', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(764, '201511017', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(765, '201511017', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(766, '201511017', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(767, '201511017', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(768, '201511036', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(769, '201511036', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(770, '201511036', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(771, '201511036', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(772, '201511036', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(773, '201511036', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(774, '201511036', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(775, '201511036', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(776, '201511036', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(777, '201511036', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(778, '201511036', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(779, '201411077', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(780, '201411077', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(781, '201411077', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00');
INSERT INTO `krs` (`KRS_ID`, `NIM`, `Tahun_ID`, `Jadwal_ID`, `Kode_mtk`, `SKS`, `Tugas1`, `Tugas2`, `Presensi`, `UTS`, `UAS`, `GradeNilai`, `BobotNilai`) VALUES
(782, '201411077', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(783, '201411077', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(784, '201411077', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(785, '201411077', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(786, '201411077', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(787, '201411077', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(788, '201411077', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(789, '201411077', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(790, '201411047', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(791, '201411047', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(792, '201411047', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(793, '201411047', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(794, '201411047', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(795, '201411047', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(796, '201411047', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(797, '201411047', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(798, '201411047', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(799, '201411047', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(800, '201411047', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(801, '201411016', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(802, '201411016', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(803, '201411016', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(804, '201411016', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(805, '201411016', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(806, '201411016', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(807, '201411016', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(808, '201411016', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(809, '201411016', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(810, '201411016', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(811, '201411016', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(812, '201312008', 20152, 100, 'D107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(813, '201312008', 20152, 104, 'C117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(814, '201312008', 20152, 101, 'C108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(815, '201312008', 20152, 105, 'B117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(816, '201312008', 20152, 98, 'C119', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(817, '201312008', 20152, 102, 'B116', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(818, '201312008', 20152, 99, 'D114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(819, '201312008', 20152, 103, 'C116', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(863, '201511019', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(880, '201311059', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(858, '201511019', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(859, '201511019', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(884, '201311059', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(885, '201311059', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(881, '201311059', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(857, '201511019', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(829, '201311077', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(830, '201311077', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(831, '201311077', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(832, '201311077', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(833, '201311077', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(834, '201311077', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(835, '201311077', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(836, '201311077', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(837, '201311077', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(838, '201311086', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(839, '201311086', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(840, '201311086', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(841, '201311086', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(842, '201311086', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(843, '201311086', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(844, '201311086', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(845, '201311086', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(846, '201311086', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(861, '201511019', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(878, '201311059', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(879, '201311059', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(860, '201511019', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(856, '201511019', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(883, '201311059', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(862, '201511019', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(882, '201311059', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(864, '201511019', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(865, '201511019', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(866, '201511019', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(867, '201411029', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(868, '201411029', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(869, '201411029', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(870, '201411029', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(871, '201411029', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(872, '201411029', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(873, '201411029', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(874, '201411029', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(875, '201411029', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(876, '201411029', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(877, '201411029', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(886, '201311059', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(887, '201511002', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(888, '201511002', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(889, '201511002', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(890, '201511002', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(891, '201511002', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(892, '201511002', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(893, '201511002', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(894, '201511002', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(895, '201511002', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(896, '201511002', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(897, '201511002', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(898, '201511028', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(899, '201511028', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(900, '201511028', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(901, '201511028', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(902, '201511028', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(903, '201511028', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(904, '201511028', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(905, '201511028', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(906, '201511028', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(907, '201511028', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(908, '201511028', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(988, '201511012', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(989, '201511012', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(987, '201521012', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(986, '201521012', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(984, '201521012', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(985, '201521012', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(964, '201521002', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(965, '201521002', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1974, '201411003', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(967, '201521002', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(968, '201521002', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(969, '201521002', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(970, '201521002', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(971, '201521002', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(972, '201521002', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(973, '201521002', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(974, '201521002', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(975, '201521002', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(976, '201521012', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(977, '201521012', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1970, '201411003', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(979, '201521012', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(980, '201521012', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(981, '201521012', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(982, '201521012', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(983, '201521012', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(990, '201511012', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(991, '201511012', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(992, '201511012', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(993, '201511012', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(994, '201511012', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(995, '201511012', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(996, '201511012', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(997, '201511012', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(998, '201511012', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(999, '201312011', 20152, 101, 'C108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1000, '201312011', 20152, 105, 'B117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1001, '201312011', 20152, 98, 'C119', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1002, '201312011', 20152, 102, 'B116', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1003, '201312011', 20152, 99, 'D114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1004, '201312011', 20152, 103, 'C116', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1005, '201312011', 20152, 100, 'D107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1006, '201312011', 20152, 104, 'C117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1007, '201511013', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1008, '201511013', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1009, '201511013', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1010, '201511013', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1011, '201511013', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1012, '201511013', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1013, '201511013', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1014, '201511013', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1015, '201511013', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1016, '201511013', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1017, '201511013', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1018, '201521013', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1019, '201521013', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1020, '201521013', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1021, '201521013', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1022, '201521013', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1023, '201521013', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1024, '201521013', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1025, '201521013', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1969, '201411003', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1027, '201521013', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1028, '201521013', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1029, '201521013', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1030, '201521001', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1031, '201521001', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1032, '201521001', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1033, '201521001', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1034, '201521001', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1036, '201521001', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1037, '201521001', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1038, '201521001', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1039, '201521001', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1040, '201521001', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1041, '201521001', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1042, '201511023', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1043, '201511023', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1044, '201511023', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1045, '201511023', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1046, '201511023', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1047, '201511023', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1048, '201511023', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1049, '201511023', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1050, '201511023', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1051, '201511023', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1052, '201511023', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1053, '201312002', 20152, 101, 'C108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1054, '201312002', 20152, 105, 'B117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1055, '201312002', 20152, 98, 'C119', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1056, '201312002', 20152, 102, 'B116', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1057, '201312002', 20152, 99, 'D114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1058, '201312002', 20152, 103, 'C116', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1059, '201312002', 20152, 100, 'D107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1060, '201312002', 20152, 104, 'C117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1076, '201511014', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1077, '201511014', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1078, '201511014', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1074, '201511014', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1075, '201511014', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1071, '201511014', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1072, '201511014', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1073, '201511014', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1079, '201511014', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1080, '201511014', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1081, '201511014', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1082, '201311098', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1083, '201311098', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1084, '201311098', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1085, '201311098', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1086, '201311098', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1087, '201311098', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1088, '201311098', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1089, '201311098', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1090, '201311098', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1091, '201511025', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1092, '201511025', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1093, '201511025', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1094, '201511025', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1095, '201511025', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1096, '201511025', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1097, '201511025', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1098, '201511025', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1099, '201511025', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1100, '201511025', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1101, '201511025', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1102, '201311093', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1103, '201311093', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1104, '201311093', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1105, '201311093', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1106, '201311093', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1107, '201311093', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1108, '201311093', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1109, '201311093', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1110, '201311093', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1111, '201311065', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1112, '201311065', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1113, '201311065', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1114, '201311065', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1115, '201311065', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1116, '201311065', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1117, '201311065', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1118, '201311065', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1119, '201311065', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1120, '201311064', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1121, '201311064', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1122, '201311064', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1123, '201311064', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1124, '201311064', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1125, '201311064', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1126, '201311064', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1127, '201311064', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1128, '201311064', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1129, '201521004', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1130, '201521004', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1131, '201521004', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1132, '201521004', 20152, 84, 'D100', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1133, '201521004', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1134, '201521004', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1135, '201521004', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1136, '201521004', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1137, '201521004', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1138, '201521004', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1139, '201521004', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1140, '201521004', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1141, '201312001', 20152, 101, 'C108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1142, '201312001', 20152, 105, 'B117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1143, '201312001', 20152, 98, 'C119', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1144, '201312001', 20152, 102, 'B116', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1145, '201312001', 20152, 99, 'D114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1146, '201312001', 20152, 103, 'C116', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1147, '201312001', 20152, 100, 'D107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1148, '201312001', 20152, 104, 'C117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1149, '201521003', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1150, '201521003', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1151, '201521003', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1152, '201521003', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1153, '201521003', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1154, '201521003', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1155, '201521003', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1156, '201521003', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1973, '201411003', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1158, '201521003', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1159, '201521003', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1160, '201521003', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1975, '201411003', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1162, '201421010', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1163, '201421010', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1164, '201421010', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1165, '201421010', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1166, '201421010', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1167, '201421010', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1168, '201421010', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1169, '201421010', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1170, '201421010', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1171, '201421010', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1172, '201421010', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1173, '201421009', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1174, '201421009', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1175, '201421009', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1176, '201421009', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1177, '201421009', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1178, '201421009', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1179, '201421009', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1180, '201421009', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1181, '201421009', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1182, '201421009', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1183, '201421009', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1184, '201421012', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1185, '201421012', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1186, '201421012', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1187, '201421012', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1188, '201421012', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1189, '201421012', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1190, '201421012', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1191, '201421012', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1192, '201421012', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1193, '201421012', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1194, '201421012', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1195, '201421011', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1196, '201421011', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1197, '201421011', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1198, '201421011', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1199, '201421011', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1200, '201421011', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1201, '201421011', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1202, '201421011', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1203, '201421011', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1204, '201421011', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1205, '201421011', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1206, '201311078', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1207, '201311078', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1208, '201311078', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1209, '201311078', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1210, '201311078', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1211, '201311078', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1212, '201311078', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1213, '201311078', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1214, '201311078', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1215, '201421013', 20152, 88, 'C101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1216, '201421013', 20152, 92, 'B106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1217, '201421013', 20152, 96, 'C102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1218, '201421013', 20152, 89, 'B113', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1219, '201421013', 20152, 93, 'B111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1220, '201421013', 20152, 97, 'B114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1221, '201421013', 20152, 90, 'B112', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1222, '201421013', 20152, 94, 'C115', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1223, '201421013', 20152, 87, 'B115', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1224, '201421013', 20152, 91, 'D113', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1225, '201421013', 20152, 95, 'C111', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1226, '201521006', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1227, '201521006', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1228, '201521006', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1229, '201521006', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1230, '201521006', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1231, '201521006', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1232, '201521006', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1233, '201521006', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1234, '201521006', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1235, '201521006', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1236, '201521006', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1238, '201521007', 20152, 76, 'A107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1239, '201521007', 20152, 80, 'A110', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1240, '201521007', 20152, 85, 'B102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1241, '201521007', 20152, 77, 'C114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1242, '201521007', 20152, 81, 'B101', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1243, '201521007', 20152, 86, 'C118', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1244, '201521007', 20152, 74, 'A101', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1245, '201521007', 20152, 78, 'A103', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1246, '201521007', 20152, 83, 'A102', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1247, '201521007', 20152, 75, 'E106', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1248, '201521007', 20152, 79, 'B103', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1972, '201411003', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1250, '201311055', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1251, '201311055', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1252, '201311055', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1253, '201311055', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1254, '201311055', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1255, '201311055', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1256, '201311055', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1257, '201311055', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1258, '201311055', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1259, '201311003', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1260, '201311003', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1261, '201311003', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1262, '201311003', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1263, '201311003', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1264, '201311003', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1265, '201311003', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1266, '201311003', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1267, '201311003', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1268, '201411019', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1269, '201411019', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1270, '201411019', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1271, '201411019', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1272, '201411019', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1273, '201411019', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1274, '201411019', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1275, '201411019', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1276, '201411019', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1277, '201411019', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1278, '201411019', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1279, '201411067', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1280, '201411067', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1281, '201411067', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1282, '201411067', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1283, '201411067', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1284, '201411067', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1285, '201411067', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1286, '201411067', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1287, '201411067', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1288, '201411067', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1289, '201411067', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1290, '201411080', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1291, '201411080', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1292, '201411080', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1293, '201411080', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1294, '201411080', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1295, '201411080', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1296, '201411080', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1297, '201411080', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1298, '201411080', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1299, '201411080', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1300, '201411080', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1301, '201411071', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1302, '201411071', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1303, '201411071', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1304, '201411071', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1305, '201411071', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1306, '201411071', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1307, '201411071', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1308, '201411071', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1309, '201411071', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1310, '201411071', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1311, '201411071', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1312, '201411042', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1313, '201411042', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1314, '201411042', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1315, '201411042', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1316, '201411042', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1317, '201411042', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1318, '201411042', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1319, '201411042', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1320, '201411042', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1321, '201411042', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1322, '201411042', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1323, '201311048', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1324, '201311048', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1325, '201311048', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1326, '201311048', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1327, '201311048', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1328, '201311048', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1329, '201311048', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1330, '201311048', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1331, '201311048', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1332, '201312010', 20152, 99, 'D114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1333, '201312010', 20152, 103, 'C116', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1334, '201312010', 20152, 100, 'D107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1335, '201312010', 20152, 104, 'C117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1336, '201312010', 20152, 101, 'C108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1337, '201312010', 20152, 105, 'B117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1338, '201312010', 20152, 98, 'C119', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1339, '201312010', 20152, 102, 'B116', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1340, '201312004', 20152, 100, 'D107', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1341, '201312004', 20152, 104, 'C117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1342, '201312004', 20152, 101, 'C108', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1343, '201312004', 20152, 105, 'B117', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1344, '201312004', 20152, 98, 'C119', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1345, '201312004', 20152, 102, 'B116', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1346, '201312004', 20152, 99, 'D114', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1347, '201312004', 20152, 103, 'C116', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1348, '201311027', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1349, '201311027', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1350, '201311027', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1351, '201311027', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1352, '201311027', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1353, '201311027', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1354, '201311027', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1355, '201311027', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1356, '201311027', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1357, '201311063', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1358, '201311063', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1359, '201311063', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1360, '201311063', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1361, '201311063', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1362, '201311063', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1363, '201311063', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1364, '201311063', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1365, '201311063', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1366, '201411037', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1367, '201411037', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1368, '201411037', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1369, '201411037', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1370, '201411037', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1371, '201411037', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1372, '201411037', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1373, '201411037', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1374, '201411037', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1375, '201411037', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1376, '201411037', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1377, '201511004', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1378, '201511004', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1379, '201511004', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1380, '201511004', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1381, '201511004', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1382, '201511004', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1383, '201511004', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1384, '201511004', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1385, '201511004', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1386, '201511004', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1387, '201511004', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1388, '201511005', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1389, '201511005', 20152, 35, 'IB228', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1390, '201511005', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1391, '201511005', 20152, 32, 'IA226', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1392, '201511005', 20152, 36, 'IB227', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1393, '201511005', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1394, '201511005', 20152, 33, 'IA224', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1395, '201511005', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1396, '201511005', 20152, 8, 'IA225', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1397, '201511005', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1398, '201511005', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1399, '201511002', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1400, '201511002', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1401, '201511002', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1402, '201511002', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1403, '201511002', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1404, '201511002', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1405, '201511002', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1406, '201511002', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1407, '201511002', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1408, '201511002', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1409, '201511002', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1410, '201511002', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1411, '201511001', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1412, '201511001', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1413, '201511001', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1414, '201511001', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1415, '201511001', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1416, '201511001', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1417, '201511001', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1418, '201511001', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1419, '201511001', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1420, '201511001', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1421, '201511001', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1422, '201511001', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1423, '201511003', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1424, '201511003', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1425, '201511003', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1426, '201511003', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1427, '201511003', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1428, '201511003', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1429, '201511003', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1430, '201511003', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1431, '201511003', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1432, '201511003', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1433, '201511003', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1434, '201511003', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1435, '201511004', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1436, '201511004', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1437, '201511004', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1438, '201511004', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1439, '201511004', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1440, '201511004', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1441, '201511004', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1442, '201511004', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1443, '201511004', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1444, '201511004', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1445, '201511004', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1446, '201511004', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1447, '201511005', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1448, '201511005', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1449, '201511005', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1450, '201511005', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1451, '201511005', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1452, '201511005', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1453, '201511005', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1454, '201511005', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1455, '201511005', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1456, '201511005', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1457, '201511005', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1458, '201511005', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1459, '201511006', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1460, '201511006', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1461, '201511006', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1462, '201511006', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1463, '201511006', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1464, '201511006', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1465, '201511006', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1466, '201511006', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1467, '201511006', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1468, '201511006', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1469, '201511006', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1470, '201511006', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1471, '201511007', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1472, '201511007', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1473, '201511007', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1474, '201511007', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1475, '201511007', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1476, '201511007', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1477, '201511007', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1478, '201511007', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1479, '201511007', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1480, '201511007', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1481, '201511007', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1482, '201511007', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1483, '201511008', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1484, '201511008', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1485, '201511008', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1486, '201511008', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1487, '201511008', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1488, '201511008', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1489, '201511008', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1490, '201511008', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1491, '201511008', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1492, '201511008', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1493, '201511008', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1494, '201511008', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1495, '201511009', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1496, '201511009', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1497, '201511009', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1498, '201511009', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1499, '201511009', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1500, '201511009', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1501, '201511009', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1502, '201511009', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1503, '201511009', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1504, '201511009', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1505, '201511009', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1506, '201511009', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1507, '201511010', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1508, '201511010', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1509, '201511010', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1510, '201511010', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1511, '201511010', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1512, '201511010', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1513, '201511010', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1514, '201511010', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1515, '201511010', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1516, '201511010', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1517, '201511010', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1518, '201511010', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1519, '201511011', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1520, '201511011', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1521, '201511011', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1522, '201511011', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1523, '201511011', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1524, '201511011', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1525, '201511011', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1526, '201511011', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1527, '201511011', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1528, '201511011', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1529, '201511011', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1530, '201511011', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1531, '201511012', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1532, '201511012', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1533, '201511012', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1534, '201511012', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1535, '201511012', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1536, '201511012', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1537, '201511012', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1538, '201511012', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1539, '201511012', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1540, '201511012', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1541, '201511012', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1542, '201511012', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1543, '201511013', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1544, '201511013', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1545, '201511013', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1546, '201511013', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'E', '0.00'),
(1547, '201511013', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1548, '201511013', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1549, '201511013', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1550, '201511013', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1551, '201511013', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1552, '201511013', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'E', '0.00'),
(1553, '201511013', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1554, '201511013', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1555, '201511014', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1556, '201511014', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1557, '201511014', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1558, '201511014', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1559, '201511014', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1560, '201511014', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1561, '201511014', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1562, '201511014', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1563, '201511014', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1564, '201511014', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1565, '201511014', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1566, '201511014', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1567, '201511015', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1568, '201511015', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1569, '201511015', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1570, '201511015', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1571, '201511015', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1572, '201511015', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1573, '201511015', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(1574, '201511015', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1575, '201511015', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1576, '201511015', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1577, '201511015', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1578, '201511015', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1579, '201511016', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1580, '201511016', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1581, '201511016', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00');
INSERT INTO `krs` (`KRS_ID`, `NIM`, `Tahun_ID`, `Jadwal_ID`, `Kode_mtk`, `SKS`, `Tugas1`, `Tugas2`, `Presensi`, `UTS`, `UAS`, `GradeNilai`, `BobotNilai`) VALUES
(1582, '201511016', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1583, '201511016', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1584, '201511016', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1585, '201511016', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1586, '201511016', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1587, '201511016', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1588, '201511016', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1589, '201511016', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1590, '201511016', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1591, '201511017', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1592, '201511017', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1593, '201511017', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1594, '201511017', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1595, '201511017', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1596, '201511017', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1597, '201511017', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1598, '201511017', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1599, '201511017', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1600, '201511017', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1601, '201511017', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1602, '201511017', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1603, '201511018', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1604, '201511018', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1605, '201511018', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1606, '201511018', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1607, '201511018', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1608, '201511018', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1609, '201511018', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1610, '201511018', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1611, '201511018', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1612, '201511018', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1613, '201511018', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1614, '201511018', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1615, '201511019', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1616, '201511019', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1617, '201511019', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1618, '201511019', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1619, '201511019', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1620, '201511019', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1621, '201511019', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1622, '201511019', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1623, '201511019', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1624, '201511019', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1625, '201511019', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1626, '201511019', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1627, '201511020', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1628, '201511020', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1629, '201511020', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1630, '201511020', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1631, '201511020', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1632, '201511020', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1633, '201511020', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1634, '201511020', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1635, '201511020', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1636, '201511020', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1637, '201511020', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1638, '201511020', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1639, '201511021', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(1640, '201511021', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1641, '201511021', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1642, '201511021', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1643, '201511021', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1644, '201511021', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1645, '201511021', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(1646, '201511021', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1647, '201511021', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1648, '201511021', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1649, '201511021', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1650, '201511021', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1651, '201511022', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1652, '201511022', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1653, '201511022', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1654, '201511022', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1655, '201511022', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1656, '201511022', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1657, '201511022', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1658, '201511022', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1659, '201511022', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1660, '201511022', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1661, '201511022', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1662, '201511022', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1663, '201511023', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1664, '201511023', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1665, '201511023', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1666, '201511023', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1667, '201511023', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1668, '201511023', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1669, '201511023', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1670, '201511023', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1671, '201511023', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1672, '201511023', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(1673, '201511023', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1674, '201511023', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1675, '201511024', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1676, '201511024', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1677, '201511024', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1678, '201511024', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1679, '201511024', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1680, '201511024', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1681, '201511024', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1682, '201511024', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1683, '201511024', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1684, '201511024', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1685, '201511024', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1686, '201511024', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1687, '201511025', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1688, '201511025', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1689, '201511025', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1690, '201511025', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1691, '201511025', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1692, '201511025', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1693, '201511025', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1694, '201511025', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1695, '201511025', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1696, '201511025', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1697, '201511025', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1698, '201511025', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1699, '201511026', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1700, '201511026', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1701, '201511026', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1702, '201511026', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1703, '201511026', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1704, '201511026', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1705, '201511026', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1706, '201511026', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1707, '201511026', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1708, '201511026', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1709, '201511026', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1710, '201511026', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1711, '201511027', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1712, '201511027', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1713, '201511027', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1714, '201511027', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1715, '201511027', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1716, '201511027', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1717, '201511027', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1718, '201511027', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1719, '201511027', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1720, '201511027', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1721, '201511027', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1722, '201511027', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1723, '201511028', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1724, '201511028', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1725, '201511028', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1726, '201511028', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1727, '201511028', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1728, '201511028', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1729, '201511028', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1730, '201511028', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1731, '201511028', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1732, '201511028', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1733, '201511028', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1734, '201511028', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1735, '201511029', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1736, '201511029', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1737, '201511029', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1738, '201511029', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1739, '201511029', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1740, '201511029', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1741, '201511029', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1742, '201511029', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1743, '201511029', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1744, '201511029', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1745, '201511029', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1746, '201511029', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1747, '201511030', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1748, '201511030', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1749, '201511030', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1750, '201511030', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1751, '201511030', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1752, '201511030', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1753, '201511030', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1754, '201511030', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1755, '201511030', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1756, '201511030', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1757, '201511030', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1758, '201511030', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1759, '201511031', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1760, '201511031', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1761, '201511031', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1762, '201511031', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1763, '201511031', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1764, '201511031', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1765, '201511031', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1766, '201511031', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1767, '201511031', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1768, '201511031', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1769, '201511031', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1770, '201511031', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1771, '201511032', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1772, '201511032', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1773, '201511032', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1774, '201511032', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1775, '201511032', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1776, '201511032', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1777, '201511032', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1778, '201511032', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1779, '201511032', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1780, '201511032', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1781, '201511032', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1782, '201511032', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1783, '201511033', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1784, '201511033', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1785, '201511033', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1786, '201511033', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1787, '201511033', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1788, '201511033', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1789, '201511033', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1790, '201511033', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1791, '201511033', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1792, '201511033', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1793, '201511033', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1794, '201511033', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1795, '201511034', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1796, '201511034', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1797, '201511034', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1798, '201511034', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1799, '201511034', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1800, '201511034', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1801, '201511034', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(1802, '201511034', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1803, '201511034', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1804, '201511034', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1805, '201511034', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1806, '201511034', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1807, '201511035', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1808, '201511035', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1809, '201511035', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1810, '201511035', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1811, '201511035', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1812, '201511035', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1813, '201511035', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1814, '201511035', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1815, '201511035', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1816, '201511035', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1817, '201511035', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(1818, '201511035', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1819, '201511036', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1820, '201511036', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(1821, '201511036', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1822, '201511036', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1823, '201511036', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1824, '201511036', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1825, '201511036', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1826, '201511036', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1827, '201511036', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1828, '201511036', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1829, '201511036', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1830, '201511036', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1831, '201511037', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1832, '201511037', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1833, '201511037', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1834, '201511037', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1835, '201511037', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1836, '201511037', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1837, '201511037', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1838, '201511037', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1839, '201511037', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1840, '201511037', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1841, '201511037', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1842, '201511037', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1843, '201511038', 20151, 3, 'IA134', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1844, '201511038', 20151, 11, 'IB124', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1845, '201511038', 20151, 15, 'IB123', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1846, '201511038', 20151, 6, 'IB125', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1847, '201511038', 20151, 12, 'IA121', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1848, '201511038', 20151, 27, 'IB122', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1849, '201511038', 20151, 7, 'IA125', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1850, '201511038', 20151, 13, 'IE104', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1851, '201511038', 20151, 26, 'IB126', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1852, '201511038', 20151, 4, 'IA123', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1853, '201511038', 20151, 10, 'IA122', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1854, '201511038', 20151, 14, 'IB121', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(1855, '201621001', 20152, 62, 'IB229', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1856, '201621001', 20152, 37, 'IC222', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1857, '201621001', 20152, 34, 'IB2210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1858, '201621001', 20152, 40, 'IB2211', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1859, '201621001', 20152, 9, 'IC221', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1860, '201621001', 20152, 41, 'IE421', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1861, '201621001', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1862, '201621001', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1863, '201621001', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1864, '201621001', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1865, '201621001', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1866, '201621001', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1867, '201621001', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1868, '201621001', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1869, '201621001', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1870, '201411089', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1871, '201411089', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1872, '201411089', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1873, '201411089', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1874, '201411089', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1875, '201411089', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1876, '201411089', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1877, '201411089', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1878, '201411089', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1879, '201411089', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1880, '201411089', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1881, '201311025', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1882, '201311025', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1883, '201311025', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1884, '201311025', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1885, '201311025', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1886, '201311025', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1887, '201311025', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1888, '201311025', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1889, '201311025', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1890, '201311058', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1891, '201311058', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1892, '201311058', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1893, '201311058', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1894, '201311058', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1895, '201311058', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1896, '201311058', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1897, '201311058', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1898, '201311058', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1899, '201411090', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1900, '201411090', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1901, '201411090', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1902, '201411090', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1903, '201411090', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1904, '201411090', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1905, '201411090', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1906, '201411090', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1907, '201411090', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1908, '201411090', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1909, '201411090', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1910, '201311013', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1911, '201311013', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1912, '201311013', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1913, '201311013', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1914, '201311013', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1915, '201311013', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1916, '201311013', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1917, '201311013', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1918, '201311013', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1919, '201411027', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1920, '201411027', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1921, '201411027', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1922, '201411027', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1923, '201411027', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1924, '201411027', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1925, '201411027', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1926, '201411027', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1927, '201411027', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1928, '201411027', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1929, '201411027', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1930, '201411054', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1931, '201411054', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1932, '201411054', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1933, '201411054', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1934, '201411054', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1935, '201411054', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1936, '201411054', 20152, 44, 'IA424', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1937, '201411054', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1938, '201411054', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1939, '201411054', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1940, '201411054', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1941, '201411012', 20152, 45, 'IC435', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1942, '201411012', 20152, 49, 'IB4314', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1943, '201411012', 20152, 42, 'IC436', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1944, '201411012', 20152, 46, 'IB4210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1945, '201411012', 20152, 50, 'IB428', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1946, '201411012', 20152, 43, 'IE105', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1947, '201411012', 20152, 47, 'IE422', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1948, '201411012', 20152, 51, 'IB429', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1949, '201411012', 20152, 48, 'IB4213', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1950, '201411012', 20152, 52, 'IA425', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1951, '201311018', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1952, '201311018', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1953, '201311018', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1954, '201311018', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1955, '201311018', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1956, '201311018', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1957, '201311018', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1958, '201311018', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1959, '201311018', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1960, '201311050', 20152, 55, 'IB6319', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1961, '201311050', 20152, 59, 'IB6321', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1962, '201311050', 20152, 56, 'IC6215', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1963, '201311050', 20152, 60, 'IB6220', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1964, '201311050', 20152, 53, 'IC6313', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1965, '201311050', 20152, 57, 'IC6214', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1966, '201311050', 20152, 61, 'IE623', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1967, '201311050', 20152, 54, 'IC6311', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1968, '201311050', 20152, 58, 'IC6312', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(1976, '201411003', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1977, '201411003', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1978, '201411003', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1980, '201411003', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(1981, '201411007', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1982, '201411007', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1983, '201411007', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1984, '201411007', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1985, '201411007', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1986, '201411007', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1987, '201411007', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1988, '201411007', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1989, '201411007', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(1990, '201411007', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1991, '201411007', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1992, '201411009', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1993, '201411009', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1994, '201411009', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1995, '201411009', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(1996, '201411009', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1997, '201411009', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(1998, '201411009', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(1999, '201411009', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2000, '201411009', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2001, '201411009', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2002, '201411009', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2003, '201411012', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2004, '201411012', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2005, '201411012', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2006, '201411012', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2007, '201411012', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2008, '201411012', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2009, '201411012', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2010, '201411012', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2011, '201411012', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2012, '201411012', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2013, '201411016', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2014, '201411016', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2015, '201411016', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2016, '201411016', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2017, '201411016', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2018, '201411016', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2019, '201411016', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2020, '201411016', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2021, '201411016', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2022, '201411016', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2023, '201411016', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2024, '201411018', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2025, '201411018', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2026, '201411018', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2027, '201411018', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2028, '201411018', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2029, '201411018', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2030, '201411018', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2031, '201411018', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2032, '201411018', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2033, '201411018', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2034, '201411018', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2035, '201411019', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2036, '201411019', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2037, '201411019', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2038, '201411019', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2039, '201411019', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2040, '201411019', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2041, '201411019', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2042, '201411019', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2043, '201411019', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2044, '201411019', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2045, '201411019', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2046, '201411020', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2047, '201411020', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2048, '201411020', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2049, '201411020', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2050, '201411020', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2051, '201411020', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2052, '201411020', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2053, '201411020', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2054, '201411020', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2055, '201411020', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2056, '201411020', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2057, '201411027', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2058, '201411027', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2059, '201411027', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2060, '201411027', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2061, '201411027', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2062, '201411027', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2063, '201411027', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(2064, '201411027', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'D', '1.00'),
(2065, '201411027', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2066, '201411027', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2067, '201411027', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2068, '201411029', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2069, '201411029', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2070, '201411029', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2071, '201411029', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2072, '201411029', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2073, '201411029', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(2074, '201411029', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2075, '201411029', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2076, '201411029', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2077, '201411029', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2078, '201411029', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2079, '201411030', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2080, '201411030', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2081, '201411030', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2082, '201411030', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2083, '201411030', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2084, '201411030', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2085, '201411030', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2086, '201411030', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2087, '201411030', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2088, '201411030', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2089, '201411030', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2090, '201411037', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2091, '201411037', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2092, '201411037', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2093, '201411037', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2094, '201411037', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2095, '201411037', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2096, '201411037', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2097, '201411037', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2098, '201411037', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2099, '201411037', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2100, '201411037', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2101, '201411038', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2102, '201411038', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2103, '201411038', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2104, '201411038', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2105, '201411038', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2106, '201411038', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2107, '201411038', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2108, '201411038', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2109, '201411038', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2110, '201411038', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2111, '201411038', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2112, '201411042', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2113, '201411042', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2114, '201411042', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2115, '201411042', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2116, '201411042', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2117, '201411042', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2118, '201411042', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2119, '201411042', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2120, '201411042', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2121, '201411042', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2122, '201411042', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2123, '201411047', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2124, '201411047', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2125, '201411047', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2126, '201411047', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2127, '201411047', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2128, '201411047', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2129, '201411047', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2130, '201411047', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2131, '201411047', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2132, '201411047', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2133, '201411047', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2134, '201411053', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2135, '201411053', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2136, '201411053', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2137, '201411053', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2138, '201411053', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(2139, '201411053', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2140, '201411053', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2141, '201411053', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2142, '201411053', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2143, '201411053', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2144, '201411053', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2145, '201411054', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2146, '201411054', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2147, '201411054', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2148, '201411054', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2149, '201411054', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2150, '201411054', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(2151, '201411054', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2152, '201411054', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2153, '201411054', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2154, '201411054', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2155, '201411054', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2156, '201411060', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2157, '201411060', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2158, '201411060', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2159, '201411060', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2160, '201411060', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2161, '201411060', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2162, '201411060', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2163, '201411060', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2164, '201411060', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2165, '201411060', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2166, '201411060', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2167, '201411061', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2168, '201411061', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2169, '201411061', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2170, '201411061', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2171, '201411061', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2172, '201411061', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2173, '201411061', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2174, '201411061', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2175, '201411061', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, '0', '0.00'),
(2176, '201411061', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2177, '201411061', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2178, '201411062', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2179, '201411062', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2180, '201411062', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2181, '201411062', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2182, '201411062', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2183, '201411062', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2184, '201411062', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2185, '201411062', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2186, '201411062', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2187, '201411062', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2188, '201411062', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2189, '201411064', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2190, '201411064', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2191, '201411064', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2192, '201411064', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2193, '201411064', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2194, '201411064', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2195, '201411064', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2196, '201411064', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2197, '201411064', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2198, '201411064', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2199, '201411064', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2200, '201411067', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2201, '201411067', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2202, '201411067', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2203, '201411067', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, '0', '0.00'),
(2204, '201411067', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2205, '201411067', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2206, '201411067', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2207, '201411067', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2208, '201411067', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'C', '2.00'),
(2209, '201411067', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2210, '201411067', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2211, '201411069', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2212, '201411069', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2213, '201411069', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2214, '201411069', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2215, '201411069', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2216, '201411069', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2217, '201411069', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2218, '201411069', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2219, '201411069', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2220, '201411069', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2221, '201411069', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2222, '201411070', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2223, '201411070', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2224, '201411070', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2225, '201411070', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2226, '201411070', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2227, '201411070', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2228, '201411070', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2229, '201411070', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2230, '201411070', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2231, '201411070', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2232, '201411070', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2233, '201411071', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2234, '201411071', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2235, '201411071', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2236, '201411071', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2237, '201411071', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2238, '201411071', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2239, '201411071', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2240, '201411071', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2241, '201411071', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2242, '201411071', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2243, '201411071', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2244, '201411077', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2245, '201411077', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2246, '201411077', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2247, '201411077', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2248, '201411077', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2249, '201411077', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2250, '201411077', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2251, '201411077', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2252, '201411077', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2253, '201411077', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2254, '201411077', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2255, '201411078', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2256, '201411078', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2257, '201411078', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2258, '201411078', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2259, '201411078', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2260, '201411078', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2261, '201411078', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2262, '201411078', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2263, '201411078', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2264, '201411078', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2265, '201411078', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2266, '201411080', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2267, '201411080', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2268, '201411080', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2269, '201411080', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2270, '201411080', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2271, '201411080', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2272, '201411080', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2273, '201411080', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2274, '201411080', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2275, '201411080', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2276, '201411080', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2277, '201411084', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2278, '201411084', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2279, '201411084', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2280, '201411084', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2281, '201411084', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2282, '201411084', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2283, '201411084', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2284, '201411084', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2285, '201411084', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2286, '201411084', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2287, '201411084', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2288, '201411089', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2289, '201411089', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2290, '201411089', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2291, '201411089', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2292, '201411089', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2293, '201411089', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2294, '201411089', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2295, '201411089', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2296, '201411089', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2297, '201411089', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2298, '201411089', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2339, '201411090', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00');
INSERT INTO `krs` (`KRS_ID`, `NIM`, `Tahun_ID`, `Jadwal_ID`, `Kode_mtk`, `SKS`, `Tugas1`, `Tugas2`, `Presensi`, `UTS`, `UAS`, `GradeNilai`, `BobotNilai`) VALUES
(2338, '201411090', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2331, '201411090', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2332, '201411090', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2333, '201411090', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2334, '201411090', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2335, '201411090', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2336, '201411090', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2337, '201411090', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2320, '201411091', 20151, 29, 'IB329', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2321, '201411091', 20151, 18, 'IA325', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2322, '201411091', 20151, 22, 'IC324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2323, '201411091', 20151, 23, 'IC322', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2324, '201411091', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2325, '201411091', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2326, '201411091', 20151, 19, 'IA324', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2327, '201411091', 20151, 111, 'IB3212', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2328, '201411091', 20151, 20, 'ID321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2329, '201411091', 20151, 17, 'IB3210', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2330, '201411091', 20151, 21, 'IC321', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2340, '201411090', 20151, 31, 'IB328', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2341, '201411090', 20151, 113, 'IC331', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2342, '201311003', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2343, '201311003', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2344, '201311003', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2345, '201311003', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2346, '201311003', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2347, '201311003', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2348, '201311003', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2349, '201311003', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2350, '201311003', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2351, '201311005', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2352, '201311005', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2353, '201311005', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2354, '201311005', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2355, '201311005', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2356, '201311005', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2357, '201311005', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2358, '201311005', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2359, '201311005', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2360, '201311013', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2361, '201311013', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2362, '201311013', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2363, '201311013', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2364, '201311013', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2365, '201311013', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2366, '201311013', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2367, '201311013', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2368, '201311013', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2369, '201311018', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2370, '201311018', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2371, '201311018', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2372, '201311018', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2373, '201311018', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2374, '201311018', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2375, '201311018', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2376, '201311018', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2377, '201311018', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2378, '201311022', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2379, '201311022', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2380, '201311022', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2381, '201311022', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2382, '201311022', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2383, '201311022', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2384, '201311022', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2385, '201311022', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2386, '201311023', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2387, '201311023', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2388, '201311023', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2389, '201311023', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2390, '201311023', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2391, '201311023', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2392, '201311023', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2393, '201311023', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2394, '201311023', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2395, '201311025', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2396, '201311025', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2397, '201311025', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2398, '201311025', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2399, '201311025', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2400, '201311025', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2401, '201311025', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2402, '201311025', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2403, '201311025', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2404, '201311027', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2405, '201311027', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2406, '201311027', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2407, '201311027', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2408, '201311027', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2409, '201311027', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2410, '201311027', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2411, '201311027', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2412, '201311027', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2413, '201311033', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2414, '201311033', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2415, '201311033', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2416, '201311033', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2417, '201311033', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2418, '201311033', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2419, '201311033', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2420, '201311033', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2421, '201311033', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2422, '201311037', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2423, '201311037', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2424, '201311037', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2425, '201311037', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2426, '201311037', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2427, '201311037', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2428, '201311037', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2429, '201311037', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2430, '201311037', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2431, '201311042', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2432, '201311042', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2433, '201311042', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2434, '201311042', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2435, '201311042', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2436, '201311042', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2437, '201311042', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2438, '201311042', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2439, '201311042', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2440, '201311045', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2441, '201311045', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2442, '201311045', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2443, '201311045', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2444, '201311045', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2445, '201311045', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2446, '201311045', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2447, '201311045', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2448, '201311045', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2449, '201311048', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2450, '201311048', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2451, '201311048', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2452, '201311048', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2453, '201311048', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2454, '201311048', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2455, '201311048', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2456, '201311048', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2457, '201311048', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2458, '201311050', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2459, '201311050', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2460, '201311050', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2461, '201311050', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2462, '201311050', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2463, '201311050', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2464, '201311050', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2465, '201311050', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2466, '201311050', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2467, '201311052', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2468, '201311052', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2469, '201311052', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2470, '201311052', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2471, '201311052', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2472, '201311052', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2473, '201311052', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2474, '201311052', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2475, '201311052', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2476, '201311055', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2477, '201311055', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2478, '201311055', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2479, '201311055', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2480, '201311055', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2481, '201311055', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2482, '201311055', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2483, '201311055', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2484, '201311055', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2485, '201311056', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2486, '201311056', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2487, '201311056', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2488, '201311056', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2489, '201311056', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2490, '201311056', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2491, '201311056', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2492, '201311056', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2493, '201311056', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2494, '201311058', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2495, '201311058', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2496, '201311058', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2497, '201311058', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2498, '201311058', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2499, '201311058', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2500, '201311058', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2501, '201311058', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2502, '201311058', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2503, '201311059', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2504, '201311059', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2505, '201311059', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2506, '201311059', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2507, '201311059', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2508, '201311059', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2509, '201311059', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2510, '201311059', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2511, '201311059', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2512, '201311063', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2513, '201311063', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2514, '201311063', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2515, '201311063', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2516, '201311063', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2517, '201311063', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2518, '201311063', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2519, '201311063', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2520, '201311063', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2521, '201311064', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2522, '201311064', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2523, '201311064', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2524, '201311064', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2525, '201311064', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2526, '201311064', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2527, '201311064', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2528, '201311064', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2529, '201311064', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2530, '201311065', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2531, '201311065', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2532, '201311065', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2533, '201311065', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2534, '201311065', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2535, '201311065', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2536, '201311065', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2537, '201311065', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2538, '201311065', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2539, '201311072', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2540, '201311072', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2541, '201311072', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2542, '201311072', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2543, '201311072', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2544, '201311072', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2545, '201311072', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2546, '201311072', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2547, '201311072', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2548, '201311077', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2549, '201311077', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2550, '201311077', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2551, '201311077', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2552, '201311077', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2553, '201311077', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2554, '201311077', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2555, '201311077', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2556, '201311077', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2557, '201311078', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2558, '201311078', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2559, '201311078', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2560, '201311078', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2561, '201311078', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2562, '201311078', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2563, '201311078', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2564, '201311078', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2565, '201311078', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2566, '201311084', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2567, '201311084', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2568, '201311084', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2569, '201311084', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2570, '201311084', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2571, '201311084', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2572, '201311084', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2573, '201311084', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2574, '201311084', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2575, '201311086', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2576, '201311086', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2577, '201311086', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2578, '201311086', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2579, '201311086', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2580, '201311086', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2581, '201311086', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2582, '201311086', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2583, '201311086', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2584, '201311087', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2585, '201311087', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2586, '201311087', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2587, '201311087', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2588, '201311087', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2589, '201311087', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2590, '201311087', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2591, '201311087', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2592, '201311087', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2593, '201311093', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2594, '201311093', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2595, '201311093', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2596, '201311093', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2597, '201311093', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2598, '201311093', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2599, '201311093', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2600, '201311093', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2601, '201311093', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2602, '201311095', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2603, '201311095', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2604, '201311095', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2605, '201311095', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2606, '201311095', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2607, '201311095', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2608, '201311095', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2609, '201311095', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2610, '201311095', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2611, '201311098', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2612, '201311098', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2613, '201311098', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2614, '201311098', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2615, '201311098', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2616, '201311098', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2617, '201311098', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2618, '201311098', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2619, '201311098', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2620, '201311099', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2621, '201311099', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2622, '201311099', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2623, '201311099', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2624, '201311099', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2625, '201311099', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2626, '201311099', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2627, '201311099', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2628, '201311099', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2639, '201513039', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2630, '201311106', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2631, '201311106', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2632, '201311106', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2633, '201311106', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2634, '201311106', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2635, '201311106', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2636, '201311106', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2637, '201311106', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2638, '201311106', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2640, '201513039', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2641, '201513039', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2642, '201513039', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, '0', '0.00'),
(2643, '201513039', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2644, '201513039', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2645, '201513039', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2646, '201513039', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2647, '201513039', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2648, '201311001', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2649, '201311001', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2650, '201311001', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2651, '201311001', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2652, '201311001', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2653, '201311001', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2654, '201311001', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2655, '201311001', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2656, '201311001', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2657, '201311004', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2658, '201311004', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2659, '201311004', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2660, '201311004', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2661, '201311004', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2662, '201311004', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2663, '201311004', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2664, '201311004', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2665, '201311004', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2666, '201311012', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2667, '201311012', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2668, '201311012', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2669, '201311012', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2670, '201311012', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2671, '201311012', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2672, '201311012', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2673, '201311012', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2674, '201311012', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2675, '201311020', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2676, '201311020', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2677, '201311020', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2678, '201311020', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2679, '201311020', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2680, '201311020', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2681, '201311020', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2682, '201311020', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2683, '201311020', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2684, '201311046', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2685, '201311046', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2686, '201311046', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2687, '201311046', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2688, '201311046', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2689, '201311046', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2690, '201311046', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'B', '3.00'),
(2691, '201311046', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2692, '201311046', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2693, '201311051', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2694, '201311051', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2695, '201311051', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2696, '201311051', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2697, '201311051', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2698, '201311051', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2699, '201311051', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2700, '201311051', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2701, '201311051', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2702, '201311068', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2703, '201311068', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2704, '201311068', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2705, '201311068', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2706, '201311068', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2707, '201311068', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2708, '201311068', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2709, '201311068', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2710, '201311068', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2711, '201311074', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2712, '201311074', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, '0', '0.00'),
(2713, '201311074', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2714, '201311074', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2715, '201311074', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'E', '0.00'),
(2716, '201311074', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2717, '201311074', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2718, '201311074', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2719, '201311074', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2720, '201311079', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2721, '201311079', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2722, '201311079', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2723, '201311079', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2724, '201311079', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, 'A', '4.00'),
(2725, '201311079', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2726, '201311079', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'A', '4.00'),
(2727, '201311079', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2728, '201311079', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2729, '201311092', 20151, 110, 'IB5217', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2730, '201311092', 20151, 115, 'ID532', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2731, '201311092', 20151, 119, 'IB5316', 2, 0, 0, 0, 0, 0, '0', '0.00'),
(2732, '201311092', 20151, 112, 'IC333', 2, 0, 0, 0, 0, 0, 'B', '3.00'),
(2733, '201311092', 20151, 116, 'IC529', 3, 0, 0, 0, 0, 0, 'C', '2.00'),
(2734, '201311092', 20151, 120, 'IB5218', 3, 0, 0, 0, 0, 0, '-', '0.00'),
(2735, '201311092', 20151, 117, 'IC538', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2736, '201311092', 20151, 114, 'IC527', 2, 0, 0, 0, 0, 0, '-', '0.00'),
(2737, '201311092', 20151, 118, 'IB5315', 2, 0, 0, 0, 0, 0, '-', '0.00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kurikulum`
--

CREATE TABLE `kurikulum` (
  `Kurikulum_ID` int(11) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Kode` varchar(8) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Sesi` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JmlSesi` int(11) NOT NULL DEFAULT '2',
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `kurikulum`
--

INSERT INTO `kurikulum` (`Kurikulum_ID`, `Identitas_ID`, `Jurusan_ID`, `Kode`, `Nama`, `Sesi`, `JmlSesi`, `Aktif`) VALUES
(33, 213131, 86208, '20151', 'Kurikulum 20151 Gasal', NULL, 2, 'Y'),
(34, 213131, 86208, '20152', 'kurikulum 20152 Genap', NULL, 2, 'Y'),
(38, 213131, 86208, '20141', 'kurikulum 20141 Gasal', NULL, 2, 'Y'),
(36, 213131, 60202, '20151', 'Kurikulum gasal', NULL, 2, 'Y'),
(37, 213131, 60202, '20152', 'Kurikulum genap', NULL, 2, 'Y'),
(39, 213131, 86208, '20142', 'kurikulum 20142 Genap', NULL, 2, 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `level`
--

CREATE TABLE `level` (
  `id_level` int(10) NOT NULL,
  `level` varchar(100) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `level`
--

INSERT INTO `level` (`id_level`, `level`) VALUES
(1, 'Administrator'),
(2, 'Dosen'),
(3, 'Akademik'),
(4, 'Mahasiswa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `ID` bigint(20) NOT NULL,
  `NIM` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `id_level` int(1) NOT NULL DEFAULT '4',
  `Identitas_ID` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Program_ID` int(1) DEFAULT NULL,
  `Nama` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `username` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Angkatan` varchar(8) COLLATE latin1_general_ci DEFAULT NULL,
  `Tahun_ID` int(5) NOT NULL,
  `TglSKMasuk` date NOT NULL,
  `Kurikulum_ID` int(11) NOT NULL,
  `foto` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'no_foto.jpg',
  `StatusAwal_ID` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `StatusMhsw_ID` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `PenasehatAkademik` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Kelamin` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  `WargaNegara` char(3) COLLATE latin1_general_ci DEFAULT NULL,
  `Kebangsaan` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TempatLahir` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalLahir` date DEFAULT NULL,
  `Agama` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `StatusSipil` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Alamat` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Kota` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `RT` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `RW` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePos` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Propinsi` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Negara` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Handphone` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `AlamatAsal` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `KotaAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `RTAsal` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `RWAsal` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePosAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PropinsiAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NegaraAsal` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaAyah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `AgamaAyah` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `PendidikanAyah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PekerjaanAyah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `HidupAyah` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `NamaIbu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `AgamaIbu` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `PendidikanIbu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PekerjaanIbu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `HidupIbu` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `AlamatOrtu` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `KotaOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `KodePosOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `PropinsiOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NegaraOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `TeleponOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `HandphoneOrtu` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `EmailOrtu` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `AsalSekolah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `AsalSekolah1` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JenisSekolah` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `KotaSekolah` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `JurusanSekolah_ID` varchar(3) COLLATE latin1_general_ci DEFAULT NULL,
  `NilaiSekolah` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `TahunLulus` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'N',
  `LulusUjian` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NilaiUjian` float UNSIGNED NOT NULL DEFAULT '0',
  `GradeNilai` varchar(5) COLLATE latin1_general_ci DEFAULT NULL,
  `TanggalLulus` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Lulus dari perguruan tinggi',
  `IPK` decimal(4,2) NOT NULL DEFAULT '0.00',
  `TotalSKS` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`ID`, `NIM`, `id_level`, `Identitas_ID`, `Jurusan_ID`, `Program_ID`, `Nama`, `username`, `password`, `Angkatan`, `Tahun_ID`, `TglSKMasuk`, `Kurikulum_ID`, `foto`, `StatusAwal_ID`, `StatusMhsw_ID`, `PenasehatAkademik`, `Kelamin`, `WargaNegara`, `Kebangsaan`, `TempatLahir`, `TanggalLahir`, `Agama`, `StatusSipil`, `Alamat`, `Kota`, `RT`, `RW`, `KodePos`, `Propinsi`, `Negara`, `Telepon`, `Handphone`, `Email`, `AlamatAsal`, `KotaAsal`, `RTAsal`, `RWAsal`, `KodePosAsal`, `PropinsiAsal`, `NegaraAsal`, `NamaAyah`, `AgamaAyah`, `PendidikanAyah`, `PekerjaanAyah`, `HidupAyah`, `NamaIbu`, `AgamaIbu`, `PendidikanIbu`, `PekerjaanIbu`, `HidupIbu`, `AlamatOrtu`, `KotaOrtu`, `KodePosOrtu`, `PropinsiOrtu`, `NegaraOrtu`, `TeleponOrtu`, `HandphoneOrtu`, `EmailOrtu`, `AsalSekolah`, `AsalSekolah1`, `JenisSekolah`, `KotaSekolah`, `JurusanSekolah_ID`, `NilaiSekolah`, `TahunLulus`, `aktif`, `LulusUjian`, `NilaiUjian`, `GradeNilai`, `TanggalLulus`, `IPK`, `TotalSKS`) VALUES
(3, '201511002', 4, '213131', 86208, 3, 'Abdul Ghani Farhan', '201511002', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', '0', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(2, '201511001', 4, '213131', 86208, 3, 'Aam Ilham Ramadan', '201511001', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, 'xxxx', '0000-00-00', 'ISLAM', NULL, 'xxx', 'xxxx', '000', '000', NULL, 'xxx', 'xxx', '0000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(4, '201511003', 4, '213131', 86208, 3, 'Agi Nuryana', '201511003', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(5, '201511004', 4, '213131', 86208, 3, 'Dede Arohmana', '201511004', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(6, '201511005', 4, '213131', 86208, 3, 'Dede Rahmat Solehudin', '201511005', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', '0', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(7, '201511006', 4, '213131', 86208, 3, 'Fadli Nurdin', '201511006', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(8, '201511007', 4, '213131', 86208, 3, 'Farid Hamzah', '201511007', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(9, '201511008', 4, '213131', 86208, 3, 'Fitriyani', '201511008', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'P', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(10, '201511009', 4, '213131', 86208, 3, 'Gina Fauziah Nur', '201511009', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(11, '201511010', 4, '213131', 86208, 3, 'Hamdan Ramdani', '201511010', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(12, '201511011', 4, '213131', 86208, 3, 'Ilma Nurhayati', '201511011', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(13, '201511012', 4, '213131', 86208, 3, 'Indah Rizki Muharam', '201511012', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(14, '201511013', 4, '213131', 86208, 3, 'Irfan Maulana', '201511013', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(15, '201511014', 4, '213131', 86208, 3, 'Isma Nurlaeliah', '201511014', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(16, '201511015', 4, '213131', 86208, 3, 'Jajang Ismail', '201511015', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(17, '201511016', 4, '213131', 86208, 3, 'Jujun Jumanah', '201511016', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(18, '201511017', 4, '213131', 86208, 3, 'Komalasari', '201511017', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(19, '201511018', 4, '213131', 86208, 3, 'Lies Malisa', '201511018', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(20, '201511019', 4, '213131', 86208, 3, 'lutfa hamdah', '201511019', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(21, '201511020', 4, '213131', 86208, 3, 'Mahmudin Sujai', '201511020', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(22, '201511021', 4, '213131', 86208, 3, 'Muhammad Imam Muttaqien', '201511021', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(23, '201511022', 4, '213131', 86208, 3, 'Muhammad Irfan Maulana Ismail', '201511022', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(24, '201511023', 4, '213131', 86208, 3, 'Muhammad Ramdhan', '201511023', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(25, '201511024', 4, '213131', 86208, 3, 'Nofiola Fiolita Sakri', '201511024', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', '0', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(26, '201511025', 4, '213131', 86208, 3, 'Nur hidayah', '201511025', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(27, '201511026', 4, '213131', 86208, 3, 'Opik Hidayah', '201511026', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(28, '201511027', 4, '213131', 86208, 3, 'Rahmat Badar Jaelani', '201511027', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(29, '201511028', 4, '213131', 86208, 3, 'Rengki Heryanto', '201511028', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(30, '201511029', 4, '213131', 86208, 3, 'Ridha Aulia Gandari', '201511029', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(31, '201511030', 4, '213131', 86208, 3, 'Sherlyana Nur', '201511030', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(32, '201511031', 4, '213131', 86208, 3, 'siska Apriyani', '201511031', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(33, '201511032', 4, '213131', 86208, 3, 'Siti Umu Habibah Romlah', '201511032', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(34, '201511033', 4, '213131', 86208, 3, 'Titin Siti Patimah', '201511033', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(35, '201511034', 4, '213131', 86208, 3, 'Ujang Muhamad', '201511034', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(36, '201511035', 4, '213131', 86208, 3, 'Waldy nur', 'B201511035', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(37, '201511036', 4, '213131', 86208, 3, 'Wina Karina G', '201511036', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(38, '201511037', 4, '213131', 86208, 3, 'Wulan Puspa Dwi', '201511037', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(39, '201511038', 4, '213131', 86208, 3, 'Yuni Puspita', '201511038', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(40, '201521001', 4, '213131', 60202, 3, 'Aisyah', '201521001', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(41, '201521002', 4, '213131', 60202, 3, 'Ajeng Pujawati', '201521002', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(42, '201521003', 4, '213131', 60202, 3, 'Dea Dian Komara', '201521003', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(43, '201521004', 4, '213131', 60202, 3, 'Enur Natalia Nurmala', '201521004', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(198, '201521005', 4, '213131', 86208, 4, 'Fathul Arif', '201521005', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 34, 'no_foto.jpg', 'P', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(45, '201521006', 4, '213131', 60202, 3, 'Ismi Marathus Solihah', '201521006', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(47, '201521007', 4, '213131', 60202, 3, 'Isna Siti Robiatul Adawiyah', '201521007', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, 'xxxxxxxx', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(48, '201521008', 4, '213131', 60202, 3, 'Iwan Kurniawan', '201521008', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(49, '201521009', 4, '213131', 60202, 3, 'Prayoga Fajar Dewangkara', '201521009', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(50, '201521010', 4, '213131', 60202, 3, 'R.Indah Yanuar Ramadanty', '201521010', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(51, '201521011', 4, '213131', 60202, 3, 'Sugandi', '201521011', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(52, '201521012', 4, '213131', 60202, 3, 'Sukni Marjaniyah', '201521012', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(53, '201521013', 4, '213131', 60202, 3, 'Shofiyan Mahfudh Muhyiddin', '201521013', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(54, '201421001', 4, '213131', 60202, 3, 'Ai Wiwit Irawati', '201421001', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(55, '201421002', 4, '213131', 60202, 3, 'Ariviokta Putri Shifa Ambiya S', '201421002', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(56, '201421005', 4, '213131', 60202, 3, 'Ely Siti Nurlaeli', '201421005', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(57, '201421006', 4, '213131', 60202, 3, 'Euis Rahayu', '201421006', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(58, '201421007', 4, '213131', 60202, 3, 'Hotimah', '201421007', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(59, '201421008', 4, '213131', 60202, 3, 'Laelatul Fadilah', '201421008', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(60, '201421009', 4, '213131', 60202, 3, 'Nadiah Sri Hidayati', '201421009', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(61, '201421010', 4, '213131', 60202, 3, 'Nova Khoirunisa', '201421010', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(62, '201421011', 4, '213131', 60202, 3, 'Renitha Purnamasari', '201421011', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(63, '201421012', 4, '213131', 60202, 3, 'Tika Yuliani', '201421012', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(64, '201421013', 4, '213131', 60202, 3, 'Wulan Aprianti', '201421013', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(65, '201523001', 4, '213131', 60202, 3, 'Muhammad Rasyid Ridlo', '201523001', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 37, 'no_foto.jpg', 'P', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(66, '201411003', 4, '213131', 86208, 3, 'Adi Luqman Prawira', '201411003', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, 'Sumedang', '1996-01-03', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(67, '201411007', 4, '213131', 86208, 3, 'Amalia Nuraeni Sudarya', '201411007', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(68, '201411009', 4, '213131', 86208, 3, 'Andre Maulana Fajar', '201411009', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(69, '201411012', 4, '213131', 86208, 3, 'Arif Abdurrazzaq', '201411012', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(70, '201411016', 4, '213131', 86208, 3, 'Asep Sunarya', '201411016', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(71, '201411018', 4, '213131', 86208, 3, 'Asna Nauli Rahmah', '201411018', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(72, '201411019', 4, '213131', 86208, 3, 'Ayu Rahayu', '201411019', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(73, '201411020', 4, '213131', 86208, 3, 'Azzahra Siti Khadijah', '201411020', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(74, '201411027', 4, '213131', 86208, 3, 'Dadi Sunandar', '201411027', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(75, '201411029', 4, '213131', 86208, 3, 'Dede Ahmad Maki', '201411029', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(76, '201411030', 4, '213131', 86208, 3, 'Dede Nuralami', '201411030', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(77, '201411037', 4, '213131', 86208, 3, 'Eri Jafar Sidik', '201411037', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(78, '201411038', 4, '213131', 86208, 3, 'Euis Siti Mukhlisoh', '201411038', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(79, '201411042', 4, '213131', 86208, 3, 'Gandy Riyana', '201411042', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(80, '201411047', 4, '213131', 86208, 3, 'Heni Rusmiati', '201411047', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(81, '201411053', 4, '213131', 86208, 3, 'Jajang Ahmad Syafi', '201411053', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(82, '201411054', 4, '213131', 86208, 3, 'Jejen Zaenudin Hamzah', '201411054', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(83, '201411060', 4, '213131', 86208, 3, 'Milah Jamilah', '201411060', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(84, '201411062', 4, '213131', 86208, 3, 'Muhammad Ilham Aliyudin', '201411062', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0);
INSERT INTO `mahasiswa` (`ID`, `NIM`, `id_level`, `Identitas_ID`, `Jurusan_ID`, `Program_ID`, `Nama`, `username`, `password`, `Angkatan`, `Tahun_ID`, `TglSKMasuk`, `Kurikulum_ID`, `foto`, `StatusAwal_ID`, `StatusMhsw_ID`, `PenasehatAkademik`, `Kelamin`, `WargaNegara`, `Kebangsaan`, `TempatLahir`, `TanggalLahir`, `Agama`, `StatusSipil`, `Alamat`, `Kota`, `RT`, `RW`, `KodePos`, `Propinsi`, `Negara`, `Telepon`, `Handphone`, `Email`, `AlamatAsal`, `KotaAsal`, `RTAsal`, `RWAsal`, `KodePosAsal`, `PropinsiAsal`, `NegaraAsal`, `NamaAyah`, `AgamaAyah`, `PendidikanAyah`, `PekerjaanAyah`, `HidupAyah`, `NamaIbu`, `AgamaIbu`, `PendidikanIbu`, `PekerjaanIbu`, `HidupIbu`, `AlamatOrtu`, `KotaOrtu`, `KodePosOrtu`, `PropinsiOrtu`, `NegaraOrtu`, `TeleponOrtu`, `HandphoneOrtu`, `EmailOrtu`, `AsalSekolah`, `AsalSekolah1`, `JenisSekolah`, `KotaSekolah`, `JurusanSekolah_ID`, `NilaiSekolah`, `TahunLulus`, `aktif`, `LulusUjian`, `NilaiUjian`, `GradeNilai`, `TanggalLulus`, `IPK`, `TotalSKS`) VALUES
(85, '201411064', 4, '213131', 86208, 3, 'Najiya Ulfa Mashlahat', '201411064', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(86, '201411067', 4, '213131', 86208, 3, 'Nining Suryani', '201411067', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(87, '201411069', 4, '213131', 86208, 3, 'Nurhasiah', '201411069', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(88, '201411070', 4, '213131', 86208, 3, 'Nurmala', '201411070', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(89, '201411071', 4, '213131', 86208, 3, 'Nurul Syarifatu Nisa', '201411071', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(90, '201411077', 4, '213131', 86208, 3, 'Rita Siti Nurjanah', '201411077', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(91, '201411078', 4, '213131', 86208, 3, 'Rizwan Nur Alamsyah', '201411078', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(92, '201411080', 4, '213131', 86208, 3, 'Selawati Dewi', '201411080', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(93, '201411089', 4, '213131', 86208, 3, 'Sri Farida', '201411089', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(94, '201411084', 4, '213131', 86208, 3, 'Sri Wahyuningsih', '201411084', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(96, '201411091', 4, '213131', 86208, 3, 'Vita Suci Agustine Suherman', '201411091', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(97, '201411061', 4, '213131', 86208, 3, 'Muhamad Trian Maulana Gifar S', '201411061', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(98, '201311001', 4, '213131', 86208, 3, 'Abdul Aziz Algani', '201311001', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', '0', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(99, '201311003', 4, '213131', 86208, 3, 'Acep Saepudin', '201311003', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(100, '201311004', 4, '213131', 86208, 3, 'Agus Abdurrochman', '201311004', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(101, '201311005', 4, '213131', 86208, 3, 'Agus Firmansyah', '201311005', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(102, '201311012', 4, '213131', 86208, 3, 'Asep Nopianto', '201311012', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(103, '201311013', 4, '213131', 86208, 3, 'Asep Rijal', '201311013', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(104, '201311018', 4, '213131', 86208, 3, 'Cicin Kuraesin', '201311018', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(105, '201311020', 4, '213131', 86208, 3, 'Dadan Syahidin', '201311020', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(106, '201311022', 4, '213131', 86208, 3, 'Danila Pirman Permara', '201311022', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(107, '201311023', 4, '213131', 86208, 3, 'Dapid', '201311023', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(108, '201311025', 4, '213131', 86208, 3, 'Dede Tatang Abdulah', '201311025', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(109, '201311027', 4, '213131', 86208, 3, 'Desi Arisma', '201311027', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(110, '201311033', 4, '213131', 86208, 3, 'Fauzya Romdoniah', '201311033', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(111, '201311037', 4, '213131', 86208, 3, 'Harun Abdurrahman', '201311037', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(112, '201311042', 4, '213131', 86208, 3, 'Ika Sopiatul Kamilah', '201311042', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(113, '201311045', 4, '213131', 86208, 3, 'Imas Puriyanti Dewi', '201311045', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(114, '201311046', 4, '213131', 86208, 3, 'Imas Siti Fauziah', '201311046', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(115, '201311048', 4, '213131', 86208, 3, 'Ledya Nida Fauziah', '201311048', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(116, '201311050', 4, '213131', 86208, 3, 'Lisda Lestari', '201311050', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(117, '201311051', 4, '213131', 86208, 3, 'M.Fathul Khoir', '201311051', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(118, '201311052', 4, '213131', 86208, 3, 'M.Wahid Khoerrudin', '201311052', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(119, '201311055', 4, '213131', 86208, 3, 'Maratus Solihah', '201311055', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(120, '201311056', 4, '213131', 86208, 3, 'Mira Januarita Permatasari', '201311056', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(121, '201311058', 4, '213131', 86208, 3, 'Muhammad Maksum M.', '201311058', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(122, '201311059', 4, '213131', 86208, 3, 'Munawar Ali Rosidina', '201311059', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(123, '201311063', 4, '213131', 86208, 3, 'Nelly Sri Hayati', '201311063', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(124, '201311064', 4, '213131', 86208, 3, 'Nenden Yunengsih', '201311064', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', '0', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(125, '201311065', 4, '213131', 86208, 3, 'Neni Naimah Parhani', '201311065', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(126, '201311068', 4, '213131', 86208, 3, 'Oning Runingsih', '201311068', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(127, '201311072', 4, '213131', 86208, 3, 'Pupung Purwanti', '201311072', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(128, '201311077', 4, '213131', 86208, 3, 'Saepul Wahidin', '201311077', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(129, '201311078', 4, '213131', 86208, 3, 'Salsabila Neinda Nurdyani', '201311078', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(130, '201311079', 4, '213131', 86208, 3, 'Sandi Karyana', '201311079', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(131, '201311084', 4, '213131', 86208, 3, 'Siti Maslahah M', '201311084', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(132, '201311086', 4, '213131', 86208, 3, 'Siti Nurhalimah', '201311086', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(133, '201311087', 4, '213131', 86208, 3, 'Siti Rofifah', '201311087', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(134, '201311092', 4, '213131', 86208, 3, 'Usman Said', '201311092', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(135, '201311093', 4, '213131', 86208, 3, 'Vera Ratnasari', '201311093', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(136, '201311095', 4, '213131', 86208, 3, 'Winda Siti Nuril Anwari', '201311095', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(137, '201311098', 4, '213131', 86208, 3, 'Wiwin Winarti', '201311098', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(138, '201311099', 4, '213131', 86208, 3, 'Wulan Lestari', '201311099', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(139, '201311106', 4, '213131', 86208, 3, 'Zamhur Khoerudin', '201311106', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(140, '201311074', 4, '213131', 86208, 3, 'Rahmat Harisman', '201311074', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(141, '201513039', 4, '213131', 86208, 3, 'Aneng', '201511039', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 33, 'no_foto.jpg', 'P', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(142, '201211002', 4, '213131', 86208, 3, 'Agus  Cahyadi', '201211002', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(143, '201211001', 4, '213131', 86208, 3, 'Andini Nkania Sari', '201211001', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(144, '201211006', 4, '213131', 86208, 3, 'Ani Yuliani', '201211006', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(145, '201211009', 4, '213131', 86208, 3, 'Anisa Rofi''Ah', '201211009', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(146, '201211007', 4, '213131', 86208, 3, 'Anisa Solihah', '201211007', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(147, '201211010', 4, '213131', 86208, 3, 'Asep Ramdan', '201211010', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(148, '201211011', 4, '213131', 86208, 3, 'Ateng Suteja', '201211011', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(149, '201211013', 4, '213131', 86208, 3, 'Cecep Ridwan', '201211013', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(150, '201211015', 4, '213131', 86208, 3, 'Dadan Hidayat', '201211015', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(151, '201211017', 4, '213131', 86208, 3, 'Desi Siti Nurjanah', '201211017', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(152, '201211019', 4, '213131', 86208, 3, 'Dian Fujiati Sa''Diah', '201211019', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(153, '201211020', 4, '213131', 86208, 3, 'Didin Jaenudin', '201211020', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(154, '201211021', 4, '213131', 86208, 3, 'Didin Wahyudin', '201211021', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(155, '201211022', 4, '213131', 86208, 3, 'Dini Nurbayani', '201211022', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(156, '201211023', 4, '213131', 86208, 3, 'Dinna Fauziah', '201211023', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '0', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '0', '0', NULL, '', '0', '0', '0', NULL, '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, '0', NULL, '', '0', '', 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(157, '201211025', 4, '213131', 86208, 3, 'Euis Marlina', '201211025', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(158, '201211027', 4, '213131', 86208, 3, 'Firman Fauji', '201211027', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(159, '201211028', 4, '213131', 86208, 3, 'Fitriani', '201211028', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(160, '201211029', 4, '213131', 86208, 3, 'Gina Nurul Fatonah', '201211029', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(161, '201211032', 4, '213131', 86208, 3, 'Hendra Nugraha', '201211032', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(162, '201211039', 4, '213131', 86208, 3, 'Ita Fitriani', '201211039', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(163, '201211040', 4, '213131', 86208, 3, 'Jajang Lalan Apriawan S', '201211040', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(164, '201211042', 4, '213131', 86208, 3, 'Kurnia Dewi Lwstari', '201211042', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(165, '201211045', 4, '213131', 86208, 3, 'Moch. Farhan Yajid', '201211045', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(166, '201211048', 4, '213131', 86208, 3, 'Muhamad Nur Alimudin', '201211048', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(167, '201211049', 4, '213131', 86208, 3, 'Nandang Subarman', '201211049', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0);
INSERT INTO `mahasiswa` (`ID`, `NIM`, `id_level`, `Identitas_ID`, `Jurusan_ID`, `Program_ID`, `Nama`, `username`, `password`, `Angkatan`, `Tahun_ID`, `TglSKMasuk`, `Kurikulum_ID`, `foto`, `StatusAwal_ID`, `StatusMhsw_ID`, `PenasehatAkademik`, `Kelamin`, `WargaNegara`, `Kebangsaan`, `TempatLahir`, `TanggalLahir`, `Agama`, `StatusSipil`, `Alamat`, `Kota`, `RT`, `RW`, `KodePos`, `Propinsi`, `Negara`, `Telepon`, `Handphone`, `Email`, `AlamatAsal`, `KotaAsal`, `RTAsal`, `RWAsal`, `KodePosAsal`, `PropinsiAsal`, `NegaraAsal`, `NamaAyah`, `AgamaAyah`, `PendidikanAyah`, `PekerjaanAyah`, `HidupAyah`, `NamaIbu`, `AgamaIbu`, `PendidikanIbu`, `PekerjaanIbu`, `HidupIbu`, `AlamatOrtu`, `KotaOrtu`, `KodePosOrtu`, `PropinsiOrtu`, `NegaraOrtu`, `TeleponOrtu`, `HandphoneOrtu`, `EmailOrtu`, `AsalSekolah`, `AsalSekolah1`, `JenisSekolah`, `KotaSekolah`, `JurusanSekolah_ID`, `NilaiSekolah`, `TahunLulus`, `aktif`, `LulusUjian`, `NilaiUjian`, `GradeNilai`, `TanggalLulus`, `IPK`, `TotalSKS`) VALUES
(168, '201211052', 4, '213131', 86208, 3, 'Noni Nopiani', '201211052', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(169, '201211053', 4, '213131', 86208, 3, 'Nurul Hanipa', '201211053', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(170, '201211054', 4, '213131', 86208, 3, 'Rani Sulastri', '201211054', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(171, '201211056', 4, '213131', 86208, 3, 'Reti Retniawati', '201211056', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(172, '201211057', 4, '213131', 86208, 3, 'Rida Oktaviana', '201211057', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(173, '201211058', 4, '213131', 86208, 3, 'Ridaul Jannah', '201211058', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(174, '201211059', 4, '213131', 86208, 3, 'Rifa Solihat', '201211059', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(175, '201211060', 4, '213131', 86208, 3, 'Rifan Fahrijal Arif', '201211060', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(176, '201211062', 4, '213131', 86208, 3, 'Rini Muajizah', '201211062', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(177, '201211070', 4, '213131', 86208, 3, 'Syaeful Anwar F', '201211070', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(178, '201211076', 4, '213131', 86208, 3, 'Wawan Kuswendi', '201211076', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(179, '201211077', 4, '213131', 86208, 3, 'Wina Wahidatul Ulum', '201211077', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2012', 0, '0000-00-00', 0, 'no_foto.jpg', '0', '', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(180, '201312001', 4, '213131', 60202, 3, 'Asep Aa Hidayatulloh', '201312001', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(181, '201312002', 4, '213131', 60202, 3, 'Ayu Yulia Andayani', '201312002', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(182, '201312003', 4, '213131', 60202, 3, 'Bahrul Faiz', '201312003', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(183, '201312004', 4, '213131', 60202, 3, 'Doni Yani Gunawan', '201312004', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(184, '201312005', 4, '213131', 60202, 3, 'Eva Siti Nugraha', '201312005', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(185, '201313006', 4, '213131', 60202, 3, 'Firmansyah', '201313006', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(186, '201312008', 4, '213131', 60202, 3, 'Imam Ramdhon Muchlisin', '201312008', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(187, '201312009', 4, '213131', 60202, 3, 'Kiki Agustini M', '201312009', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(188, '201312010', 4, '213131', 60202, 3, 'Kurnia Firdaus', '201312010', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(189, '201312011', 4, '213131', 60202, 3, 'Nandi Kustandi', '201312011', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(190, '201312015', 4, '213131', 60202, 3, 'Nia Darlina', '201312015', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(191, '201312012', 4, '213131', 60202, 3, 'Nurimam', '201312012', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(192, '201312013', 4, '213131', 60202, 3, 'Popong Holipah', '201312013', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(193, '201312014', 4, '213131', 60202, 3, 'Rani Lusiana Pratiwi', '201312014', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(194, '201312016', 4, '213131', 60202, 3, 'Rina Kusumah', '201312016', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(195, '201312017', 4, '213131', 60202, 3, 'Triya Lestari', '201312017', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(196, '201312020', 4, '213131', 60202, 3, 'Winna Aprilianty', '201312020', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(197, '201312021', 4, '213131', 60202, 3, 'Wulan Komalawati', '201312021', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 37, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(200, '201411090', 4, '213131', 86208, 3, 'Virda Susilawati', '201411090', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 33, 'no_foto.jpg', 'B', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(199, '201621001', 4, '213131', 86208, 3, 'Elis Komariah', '201621001', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2016', 0, '0000-00-00', 34, 'no_foto.jpg', 'P', 'A', '', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(201, '201513001', 4, '213131', 86208, 4, 'Ade Sutarja', '201513001', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 34, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(202, '201513002', 4, '213131', 86208, 4, 'Ence Suherman', '201513002', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(203, '201513003', 4, '213131', 86208, 4, 'Asep Karyana Abdul R', '201513003', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(204, '201513004', 4, '213131', 86208, 4, 'Irsyadi Kheruddin', '201513004', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(205, '201513005', 4, '213131', 86208, 4, 'Jalaluddin', '201513005', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(206, '201513006', 4, '213131', 86208, 4, 'Muhamad Sidik Samsudi', '201513006', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', NULL, NULL, NULL, NULL, '0000-00-00', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(207, '201513007', 4, '213131', 86208, 4, 'Vini Mutiara W', '201513007', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2015', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(208, '201513008', 4, '213131', 86208, 4, 'Yadi Setiadi', '201513008', 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e', '2015', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(209, '201411045', 4, '213131', 86208, 4, 'Hasan Sadikin', '201411045', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(210, '201411052', 4, '213131', 86208, 4, 'Irma Febrianti', '201411052', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(211, '201411055', 4, '213131', 86208, 4, 'Jujun Junaedi', '201411055', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(212, '201411057', 4, '213131', 86208, 4, 'Kusin', '201411057', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(213, '201411058', 4, '213131', 86208, 4, 'Liah Zakiah', '201411058', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(214, '201411076', 4, '213131', 86208, 4, 'Sofi Herliawan', '201411076', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'C', 'Uding Badrudin, M.Pd.I', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(215, '201411081', 4, '213131', 86208, 4, 'Riska Destiani', '201411081', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2014', 0, '0000-00-00', 40, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'P', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(217, '201311002', 4, '213131', 86208, 4, 'Abdul Rosid', '201311002', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 0, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(218, '201311007', 4, '213131', 86208, 4, 'Aman Abdurohman', '201311007', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 0, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0),
(219, '201311000', 4, '213131', 86208, 4, 'Apep Yahya', '201311000', 'b409e7a98ea7ac148281d519c568d290bcc82bf207c6e20e10824f2445bc2aca5b0e9efd9f8b4757acac87eac48e3df7595ce15d08e650c0e8006999fe5e86d3', '2013', 0, '0000-00-00', 0, 'no_foto.jpg', 'B', 'A', 'Uding Badrudin, M.Pd.I', 'L', NULL, NULL, '', '0000-00-00', 'ISLAM', NULL, '', '', '', '', NULL, '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'N', 'N', 0, NULL, '0000-00-00', '0.00', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `master_nilai`
--

CREATE TABLE `master_nilai` (
  `id` int(11) NOT NULL,
  `ipmin` decimal(5,2) NOT NULL,
  `ipmax` decimal(5,2) NOT NULL,
  `MaxSKS` int(3) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `master_nilai`
--

INSERT INTO `master_nilai` (`id`, `ipmin`, `ipmax`, `MaxSKS`, `Identitas_ID`, `Jurusan_ID`) VALUES
(1, '1.20', '1.69', 12, 14032012, 261),
(2, '1.70', '2.19', 16, 14032012, 261),
(3, '2.20', '2.69', 19, 14032012, 261),
(4, '2.70', '2.99', 21, 14032012, 261),
(5, '3.00', '4.00', 24, 14032012, 261),
(6, '0.00', '1.19', 9, 14032012, 261);

-- --------------------------------------------------------

--
-- Struktur dari tabel `matakuliah`
--

CREATE TABLE `matakuliah` (
  `Matakuliah_ID` int(11) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Kurikulum_ID` int(11) NOT NULL,
  `Kode_mtk` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `Nama_matakuliah` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `Nama_english` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `Semester` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `SKS` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `KelompokMtk_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `JenisMTK_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `JenisKurikulum_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `StatusMtk_ID` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Penanggungjawab` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Ket` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `matakuliah`
--

INSERT INTO `matakuliah` (`Matakuliah_ID`, `Identitas_ID`, `Jurusan_ID`, `Kurikulum_ID`, `Kode_mtk`, `Nama_matakuliah`, `Nama_english`, `Semester`, `SKS`, `KelompokMtk_ID`, `JenisMTK_ID`, `JenisKurikulum_ID`, `StatusMtk_ID`, `Penanggungjawab`, `Ket`, `Aktif`) VALUES
(107, 213131, 86208, 34, 'IB229', 'Hadist 1', '', '2', '2', '0', '0', '2', 'A', '', '', 'Y'),
(106, 213131, 86208, 34, 'IC222', 'Ilmu Pendidikan 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(105, 213131, 86208, 34, 'IB227', 'Sejarah Peradaban Islam', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(104, 213131, 86208, 34, 'IB228', 'Fiqh 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(103, 213131, 86208, 34, 'IB2210', 'Tafsir 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(102, 213131, 86208, 34, 'IA224', 'Bahasa Inggris 2', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(101, 213131, 86208, 34, 'IA226', 'Filsafat Umum', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(100, 213131, 86208, 34, 'IC221', 'MKPAI 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(98, 213131, 86208, 33, 'IB7022', 'Teori/Bimbingan Skripsi', '', '7', '2', '0', 'S', '0', 'A', '', '', 'Y'),
(99, 213131, 86208, 34, 'IA225', 'Bahasa Arab 2', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(97, 213131, 86208, 33, 'IC333', 'Filsafat Pendidikan Islam', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(96, 213131, 86208, 33, 'IB5218', 'Qiraatul kutub', '', '5', '3', '0', '0', '0', 'A', '', '', 'Y'),
(95, 213131, 86208, 33, 'IB5316', 'Etika dan Profesi Guru', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(94, 213131, 86208, 33, 'IB5315', 'Micro Teaching 1', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(93, 213131, 86208, 33, 'IC538', 'Psikologi Agama', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(92, 213131, 86208, 33, 'IC529', 'Peng Sistem Evaluasi PAI', '', '5', '3', '0', '0', '0', 'A', '', '', 'Y'),
(91, 213131, 86208, 33, 'ID532', 'Bimbingan Konseling', '', '5', '3', '0', '0', '0', 'A', '', '', 'Y'),
(90, 213131, 86208, 33, 'IC527', 'Telaah Kurikulum PAI SLTP/SLTA', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(89, 213131, 86208, 33, 'IB5217', 'Filsafat Ilmu', '', '5', '3', '0', '0', '0', 'A', '', '', 'Y'),
(88, 213131, 86208, 33, 'IB328', 'Fiqh 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(87, 213131, 86208, 33, 'IC331', 'Peren. Sistem Pengajaran PAI', '', '3', '3', '0', '0', '0', 'A', '', '', 'Y'),
(86, 213131, 86208, 33, 'IB329', 'Hadits 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(85, 213131, 86208, 33, 'IC322', 'Ilmu Pendidikan 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(84, 213131, 86208, 33, 'IC324', 'Psikologi Pendidikan', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(83, 213131, 86208, 33, 'IC321', 'MKPAI 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(82, 213131, 86208, 33, 'ID321', 'Komunikasi Pembelajaran', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(81, 213131, 86208, 33, 'IA324', 'Bahasa Inggris 3', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(80, 213131, 86208, 33, 'IA325', 'Bahasa Arab 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(79, 213131, 86208, 33, 'IB3210', 'Tafsir 2', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(78, 213131, 86208, 33, 'IB3212', 'Filsafat Islam', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(77, 213131, 86208, 33, 'IB122', 'Ulumul Hadist', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(76, 213131, 86208, 33, 'IB126', 'Akhlak Tasawuf', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(75, 213131, 86208, 33, 'IB121', 'Ilmu Fiqh', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(74, 213131, 86208, 33, 'IA121', 'PPkn', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(73, 213131, 86208, 33, 'IB124', 'Ilmu Kalam', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(72, 213131, 86208, 33, 'IA122', 'Ilmu Alamiah Dasar', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(71, 213131, 86208, 33, 'IA134', 'Bahasa Inggris', '', '1', '3', '0', '0', '0', 'A', '', '', 'Y'),
(70, 213131, 86208, 33, 'IA125', 'Bahasa Arab 1', '', '1', '3', '0', '0', '0', 'A', '', '', 'Y'),
(69, 213131, 86208, 33, 'IB125', 'Psikologi Umum', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(68, 213131, 86208, 33, 'IB123', 'Ulumul Quran', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(67, 213131, 86208, 33, 'IA123', 'Bahasa Indonesia', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(66, 213131, 86208, 33, 'IE104', 'Praktek Ibadah', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(108, 213131, 86208, 34, 'IB2211', 'Psikologi Perkembangan', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(109, 213131, 86208, 34, 'IE421', 'Komputer', '', '2', '3', '0', '0', '2', 'A', '', '', 'Y'),
(110, 213131, 86208, 34, 'IC436', 'Media dan Teknologi Pengajaran', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(111, 213131, 86208, 34, 'IE105', 'Praktek Tilawah', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(112, 213131, 86208, 34, 'IA424', 'Bahasa Inggris 4', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(113, 213131, 86208, 34, 'IC435', ' Statistik Pendidikan', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(114, 213131, 86208, 34, 'IB4210', 'Tafsir 3', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(115, 213131, 86208, 34, 'IE422', 'Manajemen Masjid', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(116, 213131, 86208, 34, 'IB4213', 'Ilmu pendidikan Islam', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(117, 213131, 86208, 34, 'IB4314', 'Strategi Belajar Mengajar', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(118, 213131, 86208, 34, 'IB428', 'Fiqih 3', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(119, 213131, 86208, 34, 'IA425', 'Bhasa Arab 4', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(120, 213131, 86208, 34, 'IB429', 'Hadits 3', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(121, 213131, 86208, 34, 'IC6313', 'Administrasi Pendidikan', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(122, 213131, 86208, 34, 'IC6311', 'Metode Penelitian', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(123, 213131, 86208, 34, 'IB6319', 'Kapita Selekta Pendidikan', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(124, 213131, 86208, 34, 'IC6215', 'Manajemen Sekolah', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(125, 213131, 86208, 34, 'IC6214', 'Micro Teaching', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(126, 213131, 86208, 34, 'IC6312', 'Pengembangan Kurikulum PAI', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(127, 213131, 86208, 34, 'IB6321', 'Metodologi Studi Islam', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(128, 213131, 86208, 34, 'IE623', 'Jasa Kewirausahaan', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(129, 213131, 86208, 34, 'IB6220', 'Masailul Fiqhiyah', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(218, 213131, 86208, 34, 'ID825', 'Komprehensip', '', '8', '2', '0', '0', '0', 'A', '', '', 'Y'),
(131, 213131, 86208, 35, 'ID825', 'Komprehensip', '', '8', '2', 'H', 'A', '0', 'A', '', '', 'Y'),
(132, 213131, 86208, 35, 'ID846', 'Skripsi', '', '8', '4', 'H', 'S', '0', 'A', '', '', 'Y'),
(133, 213131, 86208, 34, 'ID723', 'PPLK', '', '7', '2', 'B', 'C', '0', 'N', '', '', 'Y'),
(134, 213131, 60202, 36, 'D104', 'Pengantar Ekonomi', '', '1', '3', '0', '0', '0', 'A', '', '', 'Y'),
(135, 213131, 60202, 36, 'A111', 'Bahasa Indonesia', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(136, 213131, 60202, 36, 'A108', 'Bahasa Arab 1', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(137, 213131, 60202, 36, 'B100', 'PKN/Pancasila', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(138, 213131, 60202, 36, 'A109', 'Kewirausahaan 1', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(139, 213131, 60202, 36, 'C113', 'Praktek Ibadah', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(140, 213131, 60202, 36, 'A105', 'Pengantar Akutansi', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(141, 213131, 60202, 36, 'A100', 'Ulumul Quran', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(142, 213131, 60202, 36, 'A104', 'Pengantar Fiqih Muamalah', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(143, 213131, 60202, 36, 'D105', 'Filsafat Umum', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(144, 213131, 60202, 36, 'A112', 'Akhlak Tasawuf', '', '1', '2', '0', '0', '0', 'A', '', '', 'Y'),
(145, 213131, 60202, 36, 'B108', 'Ekonomi Mikro Islam', '', '3', '3', '0', '0', '0', 'A', '', '', 'Y'),
(146, 213131, 60202, 36, 'B109', 'Manajemen Koperasi', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(147, 213131, 60202, 36, 'B110', 'Bahasa Inggris', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(148, 213131, 60202, 36, 'B105', 'Sejarah Pemikiran Eksyar', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(149, 213131, 60202, 36, 'C110', 'Kaidah Fiqih Muamalah ', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(150, 213131, 60202, 36, 'D101', 'Kewirausahaan 3', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(151, 213131, 60202, 36, 'B107', 'Fiqih Muamalah 2', '', '3', '3', '0', '0', '0', 'A', '', '', 'Y'),
(152, 213131, 60202, 36, 'C100', 'Hadits Ekonomi', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(153, 213131, 60202, 36, 'B104', 'Pengantar Ilmu Hukum', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(154, 213131, 60202, 36, 'D102', 'Dasar - dasar Manajemen', '', '3', '2', '0', '0', '0', 'A', '', '', 'Y'),
(155, 213131, 60202, 36, 'C103', 'Kewirausahan 5', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(156, 213131, 60202, 36, 'C104', 'Asuransi  Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(157, 213131, 60202, 36, 'D103', 'Keuangan Publik Islam', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(158, 213131, 60202, 36, 'D106', 'Manajemen Perbankan Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(159, 213131, 60202, 36, 'B118', 'Pasar Modal Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(160, 213131, 60202, 36, 'D110', 'Manajemen Pembiayaan', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(161, 213131, 60202, 36, 'E107', 'Kebijakan Perekonomian di Indonesia', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(162, 213131, 60202, 36, 'C105', 'Fatwa - fatwa Ekonomi Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(163, 213131, 60202, 36, 'C106', 'Manajemen Organisasi', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(164, 213131, 60202, 36, 'C107', 'Akuntansi Syariah', '', '5', '2', '0', '0', '0', 'A', '', '', 'Y'),
(165, 213131, 60202, 36, 'C109', 'Manajemen Strategis', '', '7', '2', '0', '0', '0', 'A', '', '', 'Y'),
(166, 213131, 60202, 36, 'D111', 'Manajemen SDM/Insan Kamil', '', '7', '2', '0', '0', '0', 'A', '', '', 'Y'),
(167, 213131, 60202, 36, 'D108', 'Seminar Proposal Skripsi', '', '7', '2', '0', '0', '0', 'A', '', '', 'Y'),
(168, 213131, 60202, 36, 'C112', 'Metode Statistik', '', '7', '3', '0', '0', '0', 'A', '', '', 'Y'),
(169, 213131, 60202, 36, 'D109', 'Metodologi Penelitian Eksyar', '', '7', '3', '0', '0', '0', 'A', '', '', 'Y'),
(194, 213131, 60202, 37, 'C119', 'Ekonomi Pertanian', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(172, 213131, 60202, 37, 'B103', 'Bahasa Inggris', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(173, 213131, 60202, 37, 'A107', 'Ulum Hadits', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(174, 213131, 60202, 37, 'C114', 'Komputer', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(175, 213131, 60202, 37, 'E106', 'Sejarah Peradaban Islam', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(176, 213131, 60202, 37, 'A103', 'Ushul Fiqih', '', '2', '3', '0', '0', '0', 'A', '', '', 'Y'),
(177, 213131, 60202, 37, 'A110', 'Kewirausahaan 2', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(178, 213131, 60202, 37, 'B101', 'Bahasa Arab Ekonomi', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(179, 213131, 60202, 37, 'B102', 'ISD', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(180, 213131, 60202, 37, 'A102', 'Ilmu Kalam', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(181, 213131, 60202, 37, 'A101', 'Fiqih Muamalah 1', '', '2', '3', '0', '0', '0', 'A', '', '', 'Y'),
(182, 213131, 60202, 37, 'C111', 'Akuntansi keuangan', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(183, 213131, 60202, 37, 'C115', 'Fiqih ZIS', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(184, 213131, 60202, 37, 'B111', 'Kewirausahaan 4', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(185, 213131, 60202, 37, 'B113', 'Manajemen Pemasaran', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(186, 213131, 60202, 37, 'B112', 'Lembaga Keuangan Syariah', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(187, 213131, 60202, 37, 'D113', 'Manajemen ZIS, Haji, dan Waqaf', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(188, 213131, 60202, 37, 'B106', 'Fiqih Mawarits dan Waqaf', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(189, 213131, 60202, 37, 'B115', 'Metode Statistik 1', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(191, 213131, 60202, 37, 'C118', 'Ayat Ekonomi', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(192, 213131, 60202, 37, 'C101', 'Ekonomi Makro Islam', '', '4', '3', '0', '0', '0', 'A', '', '', 'Y'),
(193, 213131, 60202, 37, 'B114', 'Etika Bisnis Islam', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(195, 213131, 60202, 37, 'D114', 'Aspek Hukum Dalam Ekonomi', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(196, 213131, 60202, 37, 'D107', 'Analisis Laporan Keuangan', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(197, 213131, 60202, 37, 'C108', 'Kewirausahaan 6', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(198, 213131, 60202, 37, 'B116', 'Maqasid Syari''ah', '', '6', '3', '0', '0', '0', 'A', '', '', 'Y'),
(199, 213131, 60202, 37, 'C116', 'Matematika Ekonomi', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(200, 213131, 60202, 37, 'C117', 'Laboratorium BMT', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(201, 213131, 60202, 37, 'B117', 'Manajemen Risiko', '', '6', '2', '0', '0', '0', 'A', '', '', 'Y'),
(202, 213131, 60202, 37, 'C102', 'Manajemen Pembiayaan', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(203, 213131, 86208, 40, 'IC221', 'MKPAI 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(204, 213131, 86208, 40, 'IC222', 'Ilmu Pendidikan 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(205, 213131, 86208, 40, 'IB2211', 'Psikologi Perkembangan', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(206, 213131, 86208, 40, 'IE421', 'Komputer', '', '2', '3', '0', '0', '0', 'A', '', '', 'Y'),
(207, 213131, 86208, 40, 'IB2210', 'Tafsir 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(208, 213131, 86208, 40, 'IB229', 'Hadist 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(209, 213131, 86208, 40, 'IB228', 'Fiqh 1', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(210, 213131, 86208, 40, 'IA226', 'Filsafat Umum', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(211, 213131, 86208, 40, 'IA225', 'Bahasa Arab 2', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(212, 213131, 86208, 40, 'IA224', 'Bahasa Inggris 2', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(213, 213131, 86208, 40, 'IB227', 'Sejarah Peradaban Islam', '', '2', '2', '0', '0', '0', 'A', '', '', 'Y'),
(214, 213131, 86208, 40, 'IA424', 'Bahasa Inggris 4', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(215, 213131, 86208, 40, 'IA425', 'Bahasa Arab 4', '', '4', '2', '0', '0', '0', 'A', '', '', 'Y'),
(216, 213131, 86208, 40, 'IB428', 'Fiqh 3', '', '4', '2', '0', '0', '0', '', '', '', 'Y'),
(217, 213131, 86208, 34, 'ID724', 'KKN', '', '6', '2', '0', '0', '0', 'N', 'Drs.Dindin Saefudin,M.M.Pd', '', 'Y'),
(219, 213131, 86208, 34, 'ID846', 'Skripsi', '', '8', '4', '0', 'S', '0', 'A', '', '', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai`
--

CREATE TABLE `nilai` (
  `Nilai_ID` int(11) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `grade` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `bobot` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `NilaiMin` decimal(10,2) NOT NULL,
  `NilaiMax` decimal(10,2) NOT NULL,
  `keterangan` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `nilai`
--

INSERT INTO `nilai` (`Nilai_ID`, `Identitas_ID`, `Jurusan_ID`, `grade`, `bobot`, `NilaiMin`, `NilaiMax`, `keterangan`, `Aktif`) VALUES
(6, 213131, 60202, 'E', '0', '0.00', '2.99', 'Buruk Sekali', 'Y'),
(5, 213131, 86208, 'A', '4', '9.00', '100.00', 'Istimewa', 'Y'),
(4, 213131, 86208, 'B', '3', '7.00', '8.99', 'Baik Sekali', 'Y'),
(3, 213131, 86208, 'C', '2', '5.00', '6.99', 'Baik', 'Y'),
(2, 213131, 86208, 'D', '1', '3.00', '4.99', 'Buruk', 'Y'),
(1, 213131, 86208, 'E', '0', '0.00', '2.99', 'Buruk Sekali', 'Y'),
(7, 213131, 60202, 'D', '1', '3.00', '4.99', 'Buruk', 'Y'),
(8, 213131, 60202, 'C', '2', '5.00', '6.99', 'Baik', 'Y'),
(9, 213131, 60202, 'B', '3', '7.00', '8.99', 'Baik Sekali', 'Y'),
(10, 213131, 60202, 'A', '4', '9.00', '100.00', 'Istimewa', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pekerjaanortu`
--

CREATE TABLE `pekerjaanortu` (
  `Pekerjaan` char(3) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `pekerjaanortu`
--

INSERT INTO `pekerjaanortu` (`Pekerjaan`, `Nama`, `NA`) VALUES
('1', 'Pegawai Negeri', 'N'),
('2', 'ABRI', 'N'),
('3', 'Pegawai Swasta', 'N'),
('4', 'Usaha Sendiri', 'N'),
('5', 'Tidak Bekerja', 'N'),
('6', 'Pensiun', 'N'),
('7', 'Lain-lain', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendidikanortu`
--

CREATE TABLE `pendidikanortu` (
  `ID` int(1) NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `pendidikanortu`
--

INSERT INTO `pendidikanortu` (`ID`, `Nama`, `NA`) VALUES
(1, 'Tidak Tamat SD', 'N'),
(2, 'Tamat SD', 'N'),
(3, 'Tamat SMP', 'N'),
(4, 'Tamat SMTA', 'N'),
(5, 'Diploma', 'N'),
(6, 'Sarjana Muda', 'N'),
(7, 'Sarjana', 'N'),
(8, 'Pasca Sarjana', 'N'),
(9, 'Doktor', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perhatian`
--

CREATE TABLE `perhatian` (
  `ID` int(11) NOT NULL,
  `header` text COLLATE latin1_general_ci NOT NULL,
  `t1` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t2` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t3` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t4` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t5` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `t6` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `gb` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `perhatian`
--

INSERT INTO `perhatian` (`ID`, `header`, `t1`, `t2`, `t3`, `t4`, `t5`, `t6`, `gb`) VALUES
(1, '::.Warning.:: KRS YANG TELAH DI SEND/SUBMIT/KIRIM TDK BISA DIEDIT PASTIKAN SEBELUM DISEND TELITI DULU:', '1. Batas Akhir pengisian Kartu Rencana Studi (KRS) dimulai pada tanggal', '2. Perubahan Kartu Rencana Studi (KRS) tidak akan dilayani jika batas penginputan KRS telah berakhir', '', '', '', '', 'warning.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `program`
--

CREATE TABLE `program` (
  `ID` int(2) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Program_ID` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `nama_program` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `program`
--

INSERT INTO `program` (`ID`, `Identitas_ID`, `Program_ID`, `nama_program`, `aktif`) VALUES
(3, 213131, 'R', 'REGULER', 'Y'),
(4, 213131, 'N', 'NON REGULER', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `regmhs`
--

CREATE TABLE `regmhs` (
  `ID_Reg` int(11) NOT NULL,
  `Tahun` int(5) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `NIM` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `tgl_reg` date NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `regmhs`
--

INSERT INTO `regmhs` (`ID_Reg`, `Tahun`, `Identitas_ID`, `Jurusan_ID`, `NIM`, `tgl_reg`, `aktif`) VALUES
(51, 20152, 213131, 86208, '201511004', '2016-02-18', 'Y'),
(52, 20152, 213131, 86208, '201511005', '2016-02-21', 'Y'),
(53, 20151, 213131, 60202, '201521001', '2016-02-21', 'Y'),
(59, 20151, 213131, 86208, '201411003', '2016-02-21', 'Y'),
(60, 20152, 213131, 86208, '201411003', '2016-02-21', 'Y'),
(61, 20152, 213131, 86208, '201311001', '2016-02-21', 'Y'),
(62, 20152, 213131, 86208, '201411038', '2016-02-22', 'Y'),
(63, 20152, 213131, 86208, '201511007', '2016-02-22', 'Y'),
(64, 20152, 213131, 86208, '201511003', '2016-02-22', 'Y'),
(65, 20152, 213131, 86208, '201511032', '2016-02-22', 'Y'),
(66, 20152, 213131, 86208, '201511015', '2016-02-22', 'Y'),
(67, 20152, 213131, 86208, '201511011', '2016-02-22', 'Y'),
(68, 20152, 213131, 86208, '201511031', '2016-02-22', 'Y'),
(69, 20152, 213131, 86208, '201511030', '2016-02-22', 'Y'),
(70, 20152, 213131, 86208, '201511038', '2016-02-22', 'Y'),
(71, 20152, 213131, 86208, '201511008', '2016-02-22', 'Y'),
(72, 20152, 213131, 86208, '201511024', '2016-02-22', 'Y'),
(73, 20152, 213131, 86208, '201511029', '2016-02-22', 'Y'),
(74, 20152, 213131, 86208, '201411070', '2016-02-22', 'Y'),
(75, 20152, 213131, 86208, '201411018', '2016-02-22', 'Y'),
(76, 20152, 213131, 86208, '201511026', '2016-02-22', 'Y'),
(77, 20152, 213131, 60202, '201521001', '2016-02-22', 'Y'),
(78, 20152, 213131, 60202, '201521002', '2016-02-22', 'Y'),
(79, 20152, 213131, 60202, '201521003', '2016-02-22', 'Y'),
(80, 20152, 213131, 60202, '201521004', '2016-02-22', 'Y'),
(81, 20152, 213131, 60202, '201521005', '2016-02-22', 'Y'),
(82, 20152, 213131, 60202, '201521006', '2016-02-22', 'Y'),
(83, 20152, 213131, 60202, '201521007', '2016-02-22', 'Y'),
(84, 20152, 213131, 60202, '201521008', '2016-02-22', 'Y'),
(85, 20152, 213131, 60202, '201521009', '2016-02-22', 'Y'),
(86, 20152, 213131, 60202, '201521010', '2016-02-22', 'Y'),
(87, 20152, 213131, 60202, '201521011', '2016-02-22', 'Y'),
(88, 20152, 213131, 60202, '201521012', '2016-02-22', 'Y'),
(89, 20152, 213131, 60202, '201521013', '2016-02-22', 'Y'),
(90, 20152, 213131, 60202, '201523001', '2016-02-22', 'Y'),
(91, 20152, 213131, 60202, '201421001', '2016-02-22', 'Y'),
(92, 20152, 213131, 60202, '201421002', '2016-02-22', 'Y'),
(93, 20152, 213131, 60202, '201421005', '2016-02-22', 'Y'),
(94, 20152, 213131, 60202, '201421006', '2016-02-22', 'Y'),
(95, 20152, 213131, 60202, '201421007', '2016-02-22', 'Y'),
(96, 20152, 213131, 60202, '201421008', '2016-02-22', 'Y'),
(97, 20152, 213131, 60202, '201421009', '2016-02-22', 'Y'),
(98, 20152, 213131, 60202, '201421010', '2016-02-22', 'Y'),
(99, 20152, 213131, 60202, '201421011', '2016-02-22', 'Y'),
(100, 20152, 213131, 60202, '201421012', '2016-02-22', 'Y'),
(101, 20152, 213131, 60202, '201421013', '2016-02-22', 'Y'),
(102, 20152, 213131, 60202, '201312001', '2016-02-22', 'Y'),
(103, 20152, 213131, 60202, '201312002', '2016-02-22', 'Y'),
(104, 20152, 213131, 60202, '201312003', '2016-02-22', 'Y'),
(105, 20152, 213131, 60202, '201312004', '2016-02-22', 'Y'),
(106, 20152, 213131, 60202, '201312005', '2016-02-22', 'Y'),
(107, 20152, 213131, 60202, '201312008', '2016-02-22', 'Y'),
(108, 20152, 213131, 60202, '201312009', '2016-02-22', 'Y'),
(109, 20152, 213131, 60202, '201312010', '2016-02-22', 'Y'),
(110, 20152, 213131, 60202, '201312011', '2016-02-22', 'Y'),
(111, 20152, 213131, 60202, '201312012', '2016-02-22', 'Y'),
(112, 20152, 213131, 60202, '201312013', '2016-02-22', 'Y'),
(113, 20152, 213131, 60202, '201312014', '2016-02-22', 'Y'),
(114, 20152, 213131, 60202, '201312015', '2016-02-22', 'Y'),
(115, 20152, 213131, 60202, '201312016', '2016-02-22', 'Y'),
(116, 20152, 213131, 60202, '201312017', '2016-02-22', 'Y'),
(117, 20152, 213131, 60202, '201312020', '2016-02-22', 'Y'),
(118, 20152, 213131, 60202, '201312021', '2016-02-22', 'Y'),
(119, 20152, 213131, 60202, '201313006', '2016-02-22', 'Y'),
(120, 20152, 213131, 86208, '201311003', '2016-02-23', 'Y'),
(121, 20152, 213131, 86208, '201311004', '2016-02-23', 'Y'),
(122, 20152, 213131, 86208, '201311005', '2016-02-23', 'Y'),
(123, 20152, 213131, 86208, '201311012', '2016-02-23', 'Y'),
(124, 20152, 213131, 86208, '201311013', '2016-02-23', 'Y'),
(125, 20152, 213131, 86208, '201311018', '2016-02-23', 'Y'),
(126, 20152, 213131, 86208, '201311020', '2016-02-23', 'Y'),
(127, 20152, 213131, 86208, '201311022', '2016-02-23', 'Y'),
(128, 20152, 213131, 86208, '201311023', '2016-02-23', 'Y'),
(129, 20152, 213131, 86208, '201311025', '2016-02-23', 'Y'),
(130, 20152, 213131, 86208, '201311027', '2016-02-23', 'Y'),
(131, 20152, 213131, 86208, '201311033', '2016-02-23', 'Y'),
(132, 20152, 213131, 86208, '201311037', '2016-02-23', 'Y'),
(133, 20152, 213131, 86208, '201311042', '2016-02-23', 'Y'),
(134, 20152, 213131, 86208, '201311045', '2016-02-23', 'Y'),
(135, 20152, 213131, 86208, '201311046', '2016-02-23', 'Y'),
(136, 20152, 213131, 86208, '201311048', '2016-02-23', 'Y'),
(137, 20152, 213131, 86208, '201311050', '2016-02-23', 'Y'),
(138, 20152, 213131, 86208, '201311051', '2016-02-23', 'Y'),
(139, 20152, 213131, 86208, '201311052', '2016-02-23', 'Y'),
(140, 20152, 213131, 86208, '201311055', '2016-02-23', 'Y'),
(141, 20152, 213131, 86208, '201311056', '2016-02-23', 'Y'),
(142, 20152, 213131, 86208, '201311058', '2016-02-23', 'Y'),
(143, 20152, 213131, 86208, '201311059', '2016-02-23', 'Y'),
(144, 20152, 213131, 86208, '201311063', '2016-02-23', 'Y'),
(145, 20152, 213131, 86208, '201311064', '2016-02-23', 'Y'),
(146, 20152, 213131, 86208, '201311065', '2016-02-23', 'Y'),
(147, 20152, 213131, 86208, '201311068', '2016-02-23', 'Y'),
(148, 20152, 213131, 86208, '201311072', '2016-02-23', 'Y'),
(149, 20152, 213131, 86208, '201311095', '2016-02-23', 'Y'),
(150, 20152, 213131, 86208, '201311093', '2016-02-23', 'Y'),
(151, 20152, 213131, 86208, '201311092', '2016-02-23', 'Y'),
(152, 20152, 213131, 86208, '201311087', '2016-02-23', 'Y'),
(153, 20152, 213131, 86208, '201311086', '2016-02-23', 'Y'),
(154, 20152, 213131, 86208, '201311084', '2016-02-23', 'Y'),
(155, 20152, 213131, 86208, '201311079', '2016-02-23', 'Y'),
(156, 20152, 213131, 86208, '201311078', '2016-02-23', 'Y'),
(157, 20152, 213131, 86208, '201311077', '2016-02-23', 'Y'),
(158, 20152, 213131, 86208, '201311074', '2016-02-23', 'Y'),
(159, 20152, 213131, 86208, '201311098', '2016-02-23', 'Y'),
(160, 20152, 213131, 86208, '201311099', '2016-02-23', 'Y'),
(161, 20152, 213131, 86208, '201311106', '2016-02-23', 'Y'),
(162, 20152, 213131, 86208, '201411007', '2016-02-23', 'Y'),
(163, 20152, 213131, 86208, '201411009', '2016-02-23', 'Y'),
(164, 20152, 213131, 86208, '201411012', '2016-02-23', 'Y'),
(165, 20152, 213131, 86208, '201411016', '2016-02-23', 'Y'),
(166, 20152, 213131, 86208, '201411019', '2016-02-23', 'Y'),
(167, 20152, 213131, 86208, '201411020', '2016-02-23', 'Y'),
(168, 20152, 213131, 86208, '201411027', '2016-02-23', 'Y'),
(169, 20152, 213131, 86208, '201411029', '2016-02-23', 'Y'),
(170, 20152, 213131, 86208, '201411062', '2016-02-23', 'Y'),
(171, 20152, 213131, 86208, '201411061', '2016-02-23', 'Y'),
(172, 20152, 213131, 86208, '201411060', '2016-02-23', 'Y'),
(173, 20152, 213131, 86208, '201411054', '2016-02-23', 'Y'),
(174, 20152, 213131, 86208, '201411053', '2016-02-23', 'Y'),
(175, 20152, 213131, 86208, '201411047', '2016-02-23', 'Y'),
(176, 20152, 213131, 86208, '201411042', '2016-02-23', 'Y'),
(177, 20152, 213131, 86208, '201411037', '2016-02-23', 'Y'),
(178, 20152, 213131, 86208, '201411030', '2016-02-23', 'Y'),
(179, 20152, 213131, 86208, '201411089', '2016-02-23', 'Y'),
(180, 20152, 213131, 86208, '201411084', '2016-02-23', 'Y'),
(181, 20152, 213131, 86208, '201411080', '2016-02-23', 'Y'),
(182, 20152, 213131, 86208, '201411078', '2016-02-23', 'Y'),
(183, 20152, 213131, 86208, '201411077', '2016-02-23', 'Y'),
(184, 20152, 213131, 86208, '201411071', '2016-02-23', 'Y'),
(185, 20152, 213131, 86208, '201411069', '2016-02-23', 'Y'),
(186, 20152, 213131, 86208, '201411067', '2016-02-23', 'Y'),
(187, 20152, 213131, 86208, '201411064', '2016-02-23', 'Y'),
(188, 20152, 213131, 86208, '201411091', '2016-02-23', 'Y'),
(189, 20152, 213131, 86208, '201511006', '2016-02-23', 'Y'),
(190, 20152, 213131, 86208, '201511009', '2016-02-23', 'Y'),
(191, 20152, 213131, 86208, '201511001', '2016-02-23', 'Y'),
(192, 20152, 213131, 86208, '201511002', '2016-02-23', 'Y'),
(193, 20152, 213131, 86208, '201511010', '2016-02-23', 'Y'),
(194, 20152, 213131, 86208, '201511020', '2016-02-23', 'Y'),
(195, 20152, 213131, 86208, '201511019', '2016-02-23', 'Y'),
(196, 20152, 213131, 86208, '201511018', '2016-02-23', 'Y'),
(197, 20152, 213131, 86208, '201511017', '2016-02-23', 'Y'),
(198, 20152, 213131, 86208, '201511016', '2016-02-23', 'Y'),
(199, 20152, 213131, 86208, '201511014', '2016-02-23', 'Y'),
(200, 20152, 213131, 86208, '201511013', '2016-02-23', 'Y'),
(201, 20152, 213131, 86208, '201511012', '2016-02-23', 'Y'),
(202, 20152, 213131, 86208, '201511028', '2016-02-23', 'Y'),
(203, 20152, 213131, 86208, '201511027', '2016-02-23', 'Y'),
(204, 20152, 213131, 86208, '201511025', '2016-02-23', 'Y'),
(205, 20152, 213131, 86208, '201511021', '2016-02-23', 'Y'),
(206, 20152, 213131, 86208, '201511022', '2016-02-23', 'Y'),
(207, 20152, 213131, 86208, '201511023', '2016-02-23', 'Y'),
(208, 20152, 213131, 86208, '201511033', '2016-02-23', 'Y'),
(209, 20152, 213131, 86208, '201511034', '2016-02-23', 'Y'),
(210, 20152, 213131, 86208, '201511035', '2016-02-23', 'Y'),
(211, 20152, 213131, 86208, '201511036', '2016-02-23', 'Y'),
(212, 20152, 213131, 86208, '201511037', '2016-02-23', 'Y'),
(213, 20152, 213131, 86208, '201513039', '2016-02-23', 'Y'),
(214, 20152, 213131, 86208, '201621001', '2016-02-29', 'Y'),
(215, 20152, 213131, 86208, '201411090', '2016-02-29', 'Y'),
(216, 20152, 213131, 86208, '201513001', '2016-03-02', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ruang`
--

CREATE TABLE `ruang` (
  `ID` int(11) NOT NULL,
  `Ruang_ID` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Kampus_ID` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Lantai` smallint(5) UNSIGNED DEFAULT '1',
  `RuangKuliah` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'Y',
  `Kapasitas` int(10) UNSIGNED DEFAULT '0',
  `KapasitasUjian` int(10) UNSIGNED DEFAULT '0',
  `Keterangan` text COLLATE latin1_general_ci,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `ruang`
--

INSERT INTO `ruang` (`ID`, `Ruang_ID`, `Nama`, `Kampus_ID`, `Lantai`, `RuangKuliah`, `Kapasitas`, `KapasitasUjian`, `Keterangan`, `Aktif`) VALUES
(15, 'RA03', 'RUANG 3', 'K1', 1, 'Y', 40, 20, '', 'Y'),
(4, 'RA01', 'RUANG 1', 'K1', 1, 'Y', 40, 20, '', 'Y'),
(14, 'RA02', 'RUANG 2', 'K1', 1, 'Y', 40, 30, '', 'Y'),
(13, 'RA05', 'RUANG 5', 'K1', 1, 'Y', 40, 30, '', 'Y'),
(16, 'RA06', 'RUANG 6', 'K1', 1, 'Y', 40, 20, '', 'Y'),
(17, 'RA04', 'RUANG 4', 'K1', 1, 'Y', 40, 20, '', 'Y'),
(18, 'RA07', 'RUANG 7', 'K1', 1, 'Y', 40, 20, '', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statusawal`
--

CREATE TABLE `statusawal` (
  `ID` int(11) NOT NULL,
  `StatusAwal_ID` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `BeliFormulir` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `JalurKhusus` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `TanpaTest` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `Catatan` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `statusawal`
--

INSERT INTO `statusawal` (`ID`, `StatusAwal_ID`, `Nama`, `BeliFormulir`, `JalurKhusus`, `TanpaTest`, `Catatan`, `Aktif`) VALUES
(1, 'P', 'Pindahan', 'Y', 'N', 'Y', '', 'Y'),
(2, 'B', 'Baru', 'Y', 'N', 'N', NULL, 'Y'),
(3, 'S', 'PSSB', 'Y', 'Y', 'Y', 'Untuk siswa SMA berprestasi', 'Y'),
(4, 'D', 'Drop-in', 'Y', 'N', 'Y', '', 'Y'),
(5, 'A', 'Asing', 'Y', 'Y', 'Y', 'Untuk calon mahasiswa asing', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statuskerja`
--

CREATE TABLE `statuskerja` (
  `ID` int(11) NOT NULL,
  `StatusKerja_ID` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `NA` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `statuskerja`
--

INSERT INTO `statuskerja` (`ID`, `StatusKerja_ID`, `Nama`, `Def`, `NA`) VALUES
(1, 'A', 'Dosen Tetap', 'N', 'N'),
(2, 'B', 'Dosen PNS Dipekerjakan', 'N', 'N'),
(3, 'C', 'Dosen Honorer PTN', 'N', 'N'),
(4, 'D', 'Dosen Honorer Non PTN', 'N', 'N'),
(5, 'E', 'Dosen Kontrak', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statusmhsw`
--

CREATE TABLE `statusmhsw` (
  `ID` int(11) NOT NULL,
  `StatusMhsw_ID` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nilai` smallint(6) NOT NULL DEFAULT '0',
  `Keluar` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `Def` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `statusmhsw`
--

INSERT INTO `statusmhsw` (`ID`, `StatusMhsw_ID`, `Nama`, `Nilai`, `Keluar`, `Def`, `Aktif`) VALUES
(1, 'A', 'Aktif', 1, 'N', 'N', 'N'),
(2, 'C', 'Cuti', 0, 'N', 'N', 'N'),
(3, 'P', 'Pasif', 1, 'N', 'Y', 'N'),
(4, 'K', 'Keluar', 0, 'Y', 'N', 'N'),
(5, 'D', 'Drop-out', 0, 'Y', 'N', 'N'),
(6, 'L', 'Lulus', 0, 'Y', 'N', 'N'),
(7, 'T', 'Tunggu Ujian', 1, 'N', 'N', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statusmtk`
--

CREATE TABLE `statusmtk` (
  `ID` int(11) NOT NULL,
  `StatusMtk_ID` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `statusmtk`
--

INSERT INTO `statusmtk` (`ID`, `StatusMtk_ID`, `Nama`, `Aktif`) VALUES
(1, 'A', 'AKTIF', 'Y'),
(2, 'H', 'HAPUS', 'Y'),
(3, 'N', 'NON AKTIF', 'Y');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statussipil`
--

CREATE TABLE `statussipil` (
  `ID` int(3) NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `statussipil`
--

INSERT INTO `statussipil` (`ID`, `Nama`, `Aktif`) VALUES
(1, 'Belum Menikah', 'N'),
(2, 'Menikah', 'N');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tahun`
--

CREATE TABLE `tahun` (
  `ID` int(11) NOT NULL,
  `Tahun_ID` int(5) NOT NULL,
  `Identitas_ID` int(5) NOT NULL,
  `Jurusan_ID` int(5) NOT NULL,
  `Program_ID` int(1) NOT NULL,
  `Nama` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `TglKRSMulai` date DEFAULT NULL,
  `TglKRSSelesai` date DEFAULT NULL,
  `TglCetakKHS` date NOT NULL DEFAULT '0000-00-00',
  `TglBayarMulai` date NOT NULL DEFAULT '0000-00-00',
  `TglBayarSelesai` date NOT NULL DEFAULT '0000-00-00',
  `TglKuliahMulai` date DEFAULT NULL,
  `TglKuliahSelesai` date DEFAULT NULL,
  `TglUTSMulai` date DEFAULT NULL,
  `TglUTSSelesai` date DEFAULT NULL,
  `TglUASMulai` date DEFAULT NULL,
  `TglUASSelesai` date DEFAULT NULL,
  `TglNilaiMulai` date NOT NULL,
  `TglNilaiSelesai` date NOT NULL,
  `HanyaAngkatan` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  `TglBuat` datetime DEFAULT NULL,
  `LoginBuat` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `TglEdit` datetime DEFAULT NULL,
  `LoginEdit` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `Catatan` text COLLATE latin1_general_ci,
  `Aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `tahun`
--

INSERT INTO `tahun` (`ID`, `Tahun_ID`, `Identitas_ID`, `Jurusan_ID`, `Program_ID`, `Nama`, `TglKRSMulai`, `TglKRSSelesai`, `TglCetakKHS`, `TglBayarMulai`, `TglBayarSelesai`, `TglKuliahMulai`, `TglKuliahSelesai`, `TglUTSMulai`, `TglUTSSelesai`, `TglUASMulai`, `TglUASSelesai`, `TglNilaiMulai`, `TglNilaiSelesai`, `HanyaAngkatan`, `TglBuat`, `LoginBuat`, `TglEdit`, `LoginEdit`, `Catatan`, `Aktif`) VALUES
(3, 20152, 213131, 86208, 3, 'Kalender Akademik Semester Genap 20152', '2016-02-17', '2016-03-14', '2016-07-12', '0000-00-00', '0000-00-00', '2016-02-29', '2016-06-19', '2016-04-18', '2016-04-24', '2016-06-27', '2016-07-03', '2016-07-05', '2016-07-11', NULL, NULL, NULL, NULL, NULL, NULL, 'Y'),
(4, 20152, 213131, 60202, 3, 'Kalender Akademik Semester Genap 20152', '2016-02-17', '2016-03-14', '2016-07-12', '0000-00-00', '0000-00-00', NULL, NULL, '2016-04-18', '2016-04-24', '2016-06-27', '2016-07-03', '2016-07-04', '2016-07-11', NULL, NULL, NULL, NULL, NULL, NULL, 'Y'),
(5, 20151, 213131, 60202, 3, 'semester gasal', '2015-09-07', '2015-09-12', '0000-00-00', '0000-00-00', '0000-00-00', NULL, NULL, '0000-00-00', '0000-00-00', NULL, '0000-00-00', '2016-02-21', '2016-03-31', NULL, NULL, NULL, NULL, NULL, NULL, 'Y'),
(6, 20151, 213131, 86208, 3, 'Kalender Gasal 20151', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', NULL, NULL, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', NULL, NULL, NULL, NULL, NULL, NULL, 'Y'),
(7, 20152, 213131, 86208, 4, 'Kalender Karyawan', '2016-03-02', '2016-04-02', '2016-04-03', '0000-00-00', '0000-00-00', NULL, NULL, '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '2016-03-02', '2016-04-02', NULL, NULL, NULL, NULL, NULL, NULL, 'Y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `agama`
--
ALTER TABLE `agama`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `akademik`
--
ALTER TABLE `akademik`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`);

--
-- Indexes for table `beritaawal`
--
ALTER TABLE `beritaawal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `username` (`username`),
  ADD KEY `NIDN` (`NIDN`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`);

--
-- Indexes for table `dropdownsystem`
--
ALTER TABLE `dropdownsystem`
  ADD PRIMARY KEY (`ID_ds`),
  ADD KEY `id_group` (`id_group`,`menu_order`);

--
-- Indexes for table `epsbed`
--
ALTER TABLE `epsbed`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `error`
--
ALTER TABLE `error`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fileupload`
--
ALTER TABLE `fileupload`
  ADD PRIMARY KEY (`File_ID`),
  ADD KEY `File_ID` (`File_ID`),
  ADD KEY `Level_ID` (`Level_ID`);

--
-- Indexes for table `groupmodul`
--
ALTER TABLE `groupmodul`
  ADD PRIMARY KEY (`id_group`),
  ADD KEY `relasi_modul` (`relasi_modul`);

--
-- Indexes for table `hakmodul`
--
ALTER TABLE `hakmodul`
  ADD PRIMARY KEY (`ID_hm`),
  ADD KEY `ID_ds` (`ID_ds`,`id_level`);

--
-- Indexes for table `hari`
--
ALTER TABLE `hari`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hidup`
--
ALTER TABLE `hidup`
  ADD PRIMARY KEY (`Hidup`);

--
-- Indexes for table `identitas`
--
ALTER TABLE `identitas`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`);

--
-- Indexes for table `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`Jabatan_ID`);

--
-- Indexes for table `jabatandikti`
--
ALTER TABLE `jabatandikti`
  ADD PRIMARY KEY (`JabatanDikti_ID`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`Jadwal_ID`),
  ADD KEY `Tahun_ID` (`Tahun_ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Program_ID` (`Program_ID`),
  ADD KEY `Kode_Mtk` (`Kode_Mtk`),
  ADD KEY `Kode_Jurusan` (`Jurusan_ID`),
  ADD KEY `Ruang_ID` (`Ruang_ID`),
  ADD KEY `Dosen_ID` (`Dosen_ID`);

--
-- Indexes for table `jeniskurikulum`
--
ALTER TABLE `jeniskurikulum`
  ADD PRIMARY KEY (`JenisKurikulum_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`),
  ADD KEY `Identitas_ID` (`Kode`);

--
-- Indexes for table `jenismk`
--
ALTER TABLE `jenismk`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `JenisMK_ID` (`JenisMTK_ID`);

--
-- Indexes for table `jenissekolah`
--
ALTER TABLE `jenissekolah`
  ADD PRIMARY KEY (`JenisSekolah_ID`);

--
-- Indexes for table `jenis_ujian`
--
ALTER TABLE `jenis_ujian`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `jenisjadwal` (`jenisjadwal`);

--
-- Indexes for table `jenjang`
--
ALTER TABLE `jenjang`
  ADD PRIMARY KEY (`Jenjang_ID`);

--
-- Indexes for table `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`);

--
-- Indexes for table `jurusansekolah`
--
ALTER TABLE `jurusansekolah`
  ADD PRIMARY KEY (`JurusanSekolah_ID`);

--
-- Indexes for table `kampus`
--
ALTER TABLE `kampus`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Kampus_ID` (`Kampus_ID`);

--
-- Indexes for table `kelompokmtk`
--
ALTER TABLE `kelompokmtk`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `KelompokMtk_ID` (`KelompokMtk_ID`);

--
-- Indexes for table `krs`
--
ALTER TABLE `krs`
  ADD PRIMARY KEY (`KRS_ID`),
  ADD KEY `NIM` (`NIM`),
  ADD KEY `Tahun_ID` (`Tahun_ID`),
  ADD KEY `Jadwal_ID` (`Jadwal_ID`),
  ADD KEY `Kode_mtk` (`Kode_mtk`);

--
-- Indexes for table `kurikulum`
--
ALTER TABLE `kurikulum`
  ADD PRIMARY KEY (`Kurikulum_ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`id_level`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `NIM` (`NIM`),
  ADD KEY `username` (`username`),
  ADD KEY `Angkatan` (`Angkatan`),
  ADD KEY `identitas_ID` (`Identitas_ID`),
  ADD KEY `Kurikulum_ID` (`Kurikulum_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`),
  ADD KEY `Program_ID` (`Program_ID`),
  ADD KEY `Tahun_ID` (`Tahun_ID`);

--
-- Indexes for table `master_nilai`
--
ALTER TABLE `master_nilai`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`);

--
-- Indexes for table `matakuliah`
--
ALTER TABLE `matakuliah`
  ADD PRIMARY KEY (`Matakuliah_ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Kode_mtk` (`Kode_mtk`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`),
  ADD KEY `Kurikulum_ID` (`Kurikulum_ID`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`Nilai_ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`);

--
-- Indexes for table `pekerjaanortu`
--
ALTER TABLE `pekerjaanortu`
  ADD PRIMARY KEY (`Pekerjaan`);

--
-- Indexes for table `pendidikanortu`
--
ALTER TABLE `pendidikanortu`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `perhatian`
--
ALTER TABLE `perhatian`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Program_ID` (`Program_ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`);

--
-- Indexes for table `regmhs`
--
ALTER TABLE `regmhs`
  ADD PRIMARY KEY (`ID_Reg`),
  ADD KEY `Tahun` (`Tahun`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`),
  ADD KEY `NIM` (`NIM`);

--
-- Indexes for table `ruang`
--
ALTER TABLE `ruang`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Ruang_ID` (`Ruang_ID`),
  ADD KEY `Kampus_ID` (`Kampus_ID`);

--
-- Indexes for table `statusawal`
--
ALTER TABLE `statusawal`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `statuskerja`
--
ALTER TABLE `statuskerja`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `StatusKerja_ID` (`StatusKerja_ID`);

--
-- Indexes for table `statusmhsw`
--
ALTER TABLE `statusmhsw`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `StatusMhsw_ID` (`StatusMhsw_ID`);

--
-- Indexes for table `statusmtk`
--
ALTER TABLE `statusmtk`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `StatusMtk_ID` (`StatusMtk_ID`);

--
-- Indexes for table `statussipil`
--
ALTER TABLE `statussipil`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tahun`
--
ALTER TABLE `tahun`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Tahun_ID` (`Tahun_ID`),
  ADD KEY `Identitas_ID` (`Identitas_ID`),
  ADD KEY `Jurusan_ID` (`Jurusan_ID`),
  ADD KEY `Program_ID` (`Program_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `agama`
--
ALTER TABLE `agama`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `akademik`
--
ALTER TABLE `akademik`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `beritaawal`
--
ALTER TABLE `beritaawal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `dosen`
--
ALTER TABLE `dosen`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `dropdownsystem`
--
ALTER TABLE `dropdownsystem`
  MODIFY `ID_ds` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `epsbed`
--
ALTER TABLE `epsbed`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `error`
--
ALTER TABLE `error`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `fileupload`
--
ALTER TABLE `fileupload`
  MODIFY `File_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `groupmodul`
--
ALTER TABLE `groupmodul`
  MODIFY `id_group` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `hakmodul`
--
ALTER TABLE `hakmodul`
  MODIFY `ID_hm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `hari`
--
ALTER TABLE `hari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `identitas`
--
ALTER TABLE `identitas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `Jadwal_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;
--
-- AUTO_INCREMENT for table `jeniskurikulum`
--
ALTER TABLE `jeniskurikulum`
  MODIFY `JenisKurikulum_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `jenismk`
--
ALTER TABLE `jenismk`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `jenissekolah`
--
ALTER TABLE `jenissekolah`
  MODIFY `JenisSekolah_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `jenis_ujian`
--
ALTER TABLE `jenis_ujian`
  MODIFY `ID` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `kampus`
--
ALTER TABLE `kampus`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `kelompokmtk`
--
ALTER TABLE `kelompokmtk`
  MODIFY `ID` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `krs`
--
ALTER TABLE `krs`
  MODIFY `KRS_ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2738;
--
-- AUTO_INCREMENT for table `kurikulum`
--
ALTER TABLE `kurikulum`
  MODIFY `Kurikulum_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=220;
--
-- AUTO_INCREMENT for table `master_nilai`
--
ALTER TABLE `master_nilai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `matakuliah`
--
ALTER TABLE `matakuliah`
  MODIFY `Matakuliah_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=220;
--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `Nilai_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pendidikanortu`
--
ALTER TABLE `pendidikanortu`
  MODIFY `ID` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `perhatian`
--
ALTER TABLE `perhatian`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `program`
--
ALTER TABLE `program`
  MODIFY `ID` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `regmhs`
--
ALTER TABLE `regmhs`
  MODIFY `ID_Reg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;
--
-- AUTO_INCREMENT for table `ruang`
--
ALTER TABLE `ruang`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `statusawal`
--
ALTER TABLE `statusawal`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `statuskerja`
--
ALTER TABLE `statuskerja`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `statusmhsw`
--
ALTER TABLE `statusmhsw`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `statusmtk`
--
ALTER TABLE `statusmtk`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `statussipil`
--
ALTER TABLE `statussipil`
  MODIFY `ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tahun`
--
ALTER TABLE `tahun`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
